/**
 *@author: WangJinTao,MengQingChang2006
 */

package jfaceViewer;

public class Animals {

	private String animal;

	public String getAnimal() {
		return animal;
	}

	public void setAnimal(String animal) {
		this.animal = animal;
	}

}
