package cn.com.chengang.sms.db;

import java.util.Collections;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import cn.com.chengang.sms.model.IUser;

public class DbOperate {
	// �����û����õ��û������緵��null���ʾ���û�������
	public IUser getUser(String userId) throws RuntimeException {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		IUser user = null;
		try {
			session.beginTransaction();
			user = getUser(session, userId);
			session.getTransaction().commit();
		} catch (Exception e) {
			session.getTransaction().rollback();
			throw new RuntimeException(e);
		}
		return user;
	}

	public IUser getUser(Session session, String userId) {
		Query q = session.createQuery("from " + IUser.class.getName() + " where userId=:userId");
		q.setParameter("userId", userId);
		List list = q.list();
		if (list.isEmpty())
			return null;
		else
			return (IUser) list.get(0);
	}

	// ���ݷ�ҳ��Ϣ����QueryInfo�õ�Ӧ�õ��û���¼ Ҫ��QueryInfo������currentPage��pageSize������
	public List<IUser> getUsers(QueryInfo qi) throws RuntimeException {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		List<IUser> list = null;
		try {
			session.beginTransaction();
			list = getUsers(session, qi);
			session.getTransaction().commit();
		} catch (Exception e) {
			session.getTransaction().rollback();
			throw new RuntimeException(e);
		}
		return list;
	}

	public List<IUser> getUsers(Session session, QueryInfo qi) {
		// �õ��ܼ�¼��
		String hql = "select count(*) from " + IUser.class.getName();
		qi.rsCount = ((Long) session.createQuery(hql).iterate().next()).intValue();
		if (qi.rsCount == 0)// ����0��ʾû�м�¼
			return Collections.emptyList();
		// �����ҳ��
		if (qi.rsCount % qi.pageSize == 0)
			qi.pageCount = qi.rsCount / qi.pageSize;
		else
			qi.pageCount = (qi.rsCount / qi.pageSize) + 1;
		// �����ʼλ�ã� (��ǰҳ��-1)*ÿҳ��¼��
		int start = (qi.currentPage - 1) * qi.pageSize;

		Query q = session.createQuery("from " + IUser.class.getName());
		q.setFirstResult(start);
		q.setMaxResults(qi.pageSize);
		return (List<IUser>)q.list();
	}
	
	// ��HQL�﷨��ɾ������,����hql��һ����ѯ�ַ���
	public void delete(String hql) throws RuntimeException {
		Session session = HibernateUtil.getSessionFactory().openSession();
		try {
			session.beginTransaction();
			delete(session, hql);
			session.getTransaction().commit();
			System.err.println("try "+session.isOpen()+"_"+session.isConnected());
		} catch (Exception e) {
			session.getTransaction().rollback();
			System.err.println("Exception "+session.isOpen()+"_"+session.isConnected());
			throw new RuntimeException(e);
		}finally{
			session.close();
			System.err.println("finally "+session.isOpen()+"_"+session.isConnected());
		}
	}
	public void delete(Session session, String hql) {
		session.createQuery(hql).executeUpdate();
	}

	// ��������ʵ���������Ӧ�ļ�¼
	public void saveOrUpdate(Object obj) throws RuntimeException {
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		try {
			session.beginTransaction();
			saveOrUpdate(session, obj);
			session.getTransaction().commit();
		} catch (Exception e) {
			session.getTransaction().rollback();
			throw new RuntimeException(e);
		}
	}
	public void saveOrUpdate(Session session, Object obj) {
		session.saveOrUpdate(obj);
	}
}
