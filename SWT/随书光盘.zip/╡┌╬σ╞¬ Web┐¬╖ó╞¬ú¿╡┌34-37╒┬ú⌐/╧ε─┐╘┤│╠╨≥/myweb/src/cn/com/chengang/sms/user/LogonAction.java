package cn.com.chengang.sms.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import cn.com.chengang.sms.Constants;
import cn.com.chengang.sms.db.DbOperate;
import cn.com.chengang.sms.model.IUser;

public class LogonAction extends Action {
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		UserForm actionForm = (UserForm) form;
		String userId = actionForm.getUserId();
		String password = actionForm.getPassword();
		IUser user = new DbOperate().getUser(userId);// �����ݿ��и���userIdȡ�ô��û�
		ActionMessages messages = new ActionMessages();
		if (user == null) {
			ActionMessage am = new ActionMessage("LogonAction.fail.userId",
					userId);
			messages.add("userId", am);
			saveErrors(request, messages);
			return (mapping.findForward("fail"));
		}
		String dbPassword = user.getPassword();
		if (dbPassword == null || !dbPassword.equals(password)) {
			ActionMessage am = new ActionMessage("LogonAction.fail.password");
			messages.add("password", am);
			saveErrors(request, messages);
			return (mapping.findForward("fail"));
		}
		HttpSession session = request.getSession();
		session.setAttribute(Constants.CURRENT_USER, user);// ����ǰ��¼�û���������
		return (mapping.findForward("success"));
	}
}
