package cn.com.chengang.sms.model;

/**
 * ѧ���ɼ�
 */
public class StudentScore {
    private Long id;
    private Exam exam; //����ʵ��
    private Student student; //ѧ��
    private float score; //�÷�

    /*********������Ӧ��Setter/Getter����*************/
    public Long getId() {return id;}
    public void setId(Long id) {this.id = id;}
    public Exam getExam() {return exam;}
    public void setExam(Exam exam) {this.exam = exam;}
    public Student getStudent() {return student; }
    public void setStudent(Student student) {this.student = student;}
    public float getScore() {return score;}
    public void setScore(float score) {this.score = score;}
}
