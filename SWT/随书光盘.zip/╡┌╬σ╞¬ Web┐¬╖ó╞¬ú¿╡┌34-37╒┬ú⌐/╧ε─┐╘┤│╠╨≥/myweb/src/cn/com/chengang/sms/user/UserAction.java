package cn.com.chengang.sms.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import cn.com.chengang.sms.db.DbOperate;
import cn.com.chengang.sms.model.IUser;

public class UserAction extends DispatchAction {
	private final static String USER = "modiUser";

	// ɾ���û���Action
	public ActionForward removeUser(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		UserForm actionForm = (UserForm) form;
		Long id = actionForm.getId();
		String hql = "delete " + IUser.class.getName() + " where id=" + id;
		new DbOperate().delete(hql);
		return (mapping.getInputForward());
	}

	// �޸��û���Action
	public ActionForward modifyUser(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		UserForm actionForm = (UserForm) form;
		IUser user = (IUser) request.getSession().getAttribute(USER);
		request.getSession().removeAttribute(USER);
		user.setUserId(actionForm.getUserId());
		user.setPassword(actionForm.getPassword());
		user.setName(actionForm.getName());
		new DbOperate().saveOrUpdate(user);// �������ݿ�
		return (mapping.findForward("modifySuccess"));
	}

	// ��ʾһ���û���Action
	public ActionForward showUser(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		UserForm actionForm = (UserForm) form;
		String userId = actionForm.getUserId();
		IUser user = new DbOperate().getUser(userId);
		actionForm.setUserId(user.getUserId());
		actionForm.setPassword(user.getPassword());
		actionForm.setName(user.getName());
		actionForm.setLatestOnline(user.getLatestOnline());
		request.getSession().setAttribute(USER, user);// �����û�״̬
		return (mapping.findForward("modifyUserView"));
	}
}
