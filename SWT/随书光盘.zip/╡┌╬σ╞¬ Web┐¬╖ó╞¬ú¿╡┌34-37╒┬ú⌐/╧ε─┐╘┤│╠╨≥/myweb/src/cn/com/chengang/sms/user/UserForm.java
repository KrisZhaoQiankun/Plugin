package cn.com.chengang.sms.user;
import java.util.Date;

import org.apache.struts.validator.ValidatorActionForm;
public class UserForm extends ValidatorActionForm {
	private static final long serialVersionUID = 3238501586467275260L;
	private String userId_abc;
	private String password;
	private Long id;  //���ݿ�ID
	private String name; //����
	private Date latestOnline;//����¼ʱ��

	public String getUserId() {return userId_abc;}
	public void setUserId(String userId) {this.userId_abc = userId;	}
	public String getPassword() {return password;	}
	public void setPassword(String password) {this.password = password;}
	public Long getId() {return id;}
	public void setId(Long id) {this.id = id;}
	public String getName() {return name;}
	public void setName(String name) {	this.name = name;}
	public Date getLatestOnline() {	return latestOnline;}
	public void setLatestOnline(Date latestOnline) {this.latestOnline = latestOnline;}
	
}
