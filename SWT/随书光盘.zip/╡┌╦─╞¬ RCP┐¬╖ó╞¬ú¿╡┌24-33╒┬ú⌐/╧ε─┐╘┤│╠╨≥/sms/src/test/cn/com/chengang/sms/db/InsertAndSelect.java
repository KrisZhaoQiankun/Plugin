package cn.com.chengang.sms.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertAndSelect {
	public static void main(String[] args) {
		Connection con = null;
		Statement sm = null;
		ResultSet rs = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/sms?useUnicode=true&characterEncoding=utf8", "root", "123456");
			sm = con.createStatement();
			// ��ձ���Ȼ�����������¼�������ȡ����ӡ����
			sm.executeUpdate("delete from test_table");
			// �����¼
			String s = "�¸�";
			sm.executeUpdate("insert into test_table (name0) values ('" + s + "')");
			sm.executeUpdate("insert into test_table (name1) values ('" + s + "')");
			sm.executeUpdate("insert into test_table (name2) values ('" + s + "')");
			sm.executeUpdate("insert into test_table (name3) values ('" + s + "')");
			// ��ȡ��¼
			rs = sm.executeQuery("select * from test_table");
			while (rs.next())
				System.out.println(rs.getInt("id") + "_" + rs.getString("name0") + "_" + rs.getString("name1") + "_" + rs.getString("name2") + "_" + rs.getString("name3"));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {// �ر����ӡ��ͷ���Դ
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				rs = null;
			}
			if (sm != null) {
				try {
					sm.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				sm = null;
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				con = null;
			}
		}
	}
}
