package cn.com.chengang.sms.db;

public class MysqlOperate extends AbstractDbOperate {

}