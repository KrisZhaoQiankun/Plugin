package cn.com.chengang.sms.db;

public class OracleOperate extends AbstractDbOperate {
	
}