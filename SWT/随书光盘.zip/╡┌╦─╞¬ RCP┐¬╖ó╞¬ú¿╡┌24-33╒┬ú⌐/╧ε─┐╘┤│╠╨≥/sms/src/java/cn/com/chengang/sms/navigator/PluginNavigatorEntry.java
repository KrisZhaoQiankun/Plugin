package cn.com.chengang.sms.navigator;
public class PluginNavigatorEntry extends NavigatorEntry {

}
