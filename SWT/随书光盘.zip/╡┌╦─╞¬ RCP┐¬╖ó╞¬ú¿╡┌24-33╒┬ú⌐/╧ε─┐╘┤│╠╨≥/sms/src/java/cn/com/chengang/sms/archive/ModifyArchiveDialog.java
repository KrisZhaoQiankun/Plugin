package cn.com.chengang.sms.archive;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.IMessageProvider;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import cn.com.chengang.sms.model.Course;
import cn.com.chengang.sms.model.IUser;
import cn.com.chengang.sms.model.SchoolClass;
import cn.com.chengang.sms.model.Student;
import cn.com.chengang.sms.model.Teacher;
import cn.com.chengang.sms.system.CourseComposite;
import cn.com.chengang.sms.system.SmsUtil;

//�޸��û���Ϣ�ĶԻ���
public class ModifyArchiveDialog extends TitleAreaDialog {
	private IUser user; // �û�ʵ��
	private Label idLabel; // id�ֶ�ֵ
	private Label latestOnlinLabel; // ����¼ʱ��
	private Text useridText; // �û���
	private Text passwordText; // ����
	private Text nameText; // ����
	private Label schoolClassLabel; // �༶��ǩ
	private Combo schoolClassCombo; // �༶�ı���
	private CourseComposite courseComp; // �γ����

	public ModifyArchiveDialog(Shell parentShell) {
		super(parentShell);
	}

	protected Control createDialogArea(Composite parent) {
		getShell().setText("�û�����");
		setTitle("�޸��û�����");
		setMessage("�������µ��û���Ϣ", IMessageProvider.INFORMATION);
		Composite topComp = new Composite(parent, SWT.NONE);
		// ���û���topComp�ڶԻ����е�λ��
		topComp.setLayoutData(new GridData(GridData.CENTER, GridData.CENTER, true, true));
		topComp.setLayout(new GridLayout(2, false));// ���񲼾֣�2��
		// �����������
		Composite comp1 = new Composite(topComp, SWT.NONE);
		comp1.setLayoutData(new GridData(GridData.FILL_BOTH));
		comp1.setLayout(new GridLayout(2, false));// ���񲼾֣�2��
		new Label(comp1, SWT.NONE).setText("ID��");
		idLabel = new Label(comp1, SWT.NONE);
		new Label(comp1, SWT.NONE).setText("�û�����");
		useridText = createText(comp1, SWT.BORDER);
		new Label(comp1, SWT.NONE).setText("���룺");
		passwordText = createText(comp1, SWT.BORDER);
		new Label(comp1, SWT.NONE).setText("������");
		nameText = createText(comp1, SWT.BORDER);
		{
			schoolClassLabel = new Label(comp1, SWT.NONE);
			schoolClassLabel.setText("�༶��");
			Composite classComp = new Composite(comp1, SWT.NONE);
			classComp.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
			classComp.setLayout(new FillLayout());
			schoolClassCombo = SmsUtil.createSchoolClassCombo(classComp, SWT.BORDER | SWT.READ_ONLY);
		}
		new Label(comp1, SWT.NONE).setText("�����¼��");
		latestOnlinLabel = new Label(comp1, SWT.NONE);
		courseComp = new CourseComposite(topComp, SWT.NONE);// �����γ����
		// ��ֵ
		setValue(user);
		return topComp;
	}

	// ���������ֵ
	private void setValue(IUser user) {
		if (user == null)
			return;
		idLabel.setText(String.valueOf(user.getId()));
		latestOnlinLabel.setText(SmsUtil.dateToLongStr(user.getLatestOnline()));
		useridText.setText(user.getUserId());
		passwordText.setText(user.getPassword());
		nameText.setText(user.getName());
		if (user instanceof Student) {
			Student o = (Student) user;
			SchoolClass schoolClass = o.getSchoolclass();
			schoolClassCombo.setText(schoolClass.getName());
			schoolClassCombo.setData(schoolClass.getName(), schoolClass);
			courseComp.setVisible(false);
		} else if (user instanceof Teacher) {
			Teacher o = (Teacher) user;
			for (Course course : o.getCourses())
				courseComp.add(course);
			schoolClassLabel.setVisible(false);// ���ذ༶
			schoolClassCombo.setVisible(false);
		}
	}

	// �õ�һ���̶����ȵ�Text��
	private Text createText(Composite comp, int style) {
		Text text = new Text(comp, style);
		text.setLayoutData(new GridData(100, -1));
		return text;
	}

	// �Ի���ť����ִ�еķ���
	protected void buttonPressed(int buttonId) {
		if (buttonId == IDialogConstants.OK_ID) {
			if (!checkValue())
				return;
			getValue(user);
		}
		super.buttonPressed(buttonId);
	}

	// �������ֵ�ĺϷ��ԣ�����false��ʾ���Ϸ�
	private boolean checkValue() {
		if (useridText.getText().trim().equals("")) {
			setErrorMessage("�û�������Ϊ��");
			return false;
		}
		if (passwordText.getText().trim().equals("")) {
			setErrorMessage("���벻��Ϊ��");
			return false;
		}
		if (nameText.getText().trim().equals("")) {
			setErrorMessage("��������Ϊ��");
			return false;
		}
		return true;
	}

	// �������ֵ���µ������user����
	private void getValue(IUser user) {
		if (user instanceof Teacher) { // �����µĿγ�ֵ
			Teacher teacher = (Teacher) user;
			teacher.clearCourses(); // �����
			for (String courseName : courseComp.getItems()) {
				Course course = courseComp.getData(courseName);
				teacher.addCourse(course);
			}
		} else if (user instanceof Student) { // �����µİ༶ֵ
			String sel = schoolClassCombo.getText();
			SchoolClass schoolclass = (SchoolClass) schoolClassCombo.getData(sel);
			((Student) user).setSchoolclass(schoolclass);
		}
		user.setId(new Long(idLabel.getText()));
		user.setUserId(useridText.getText());
		user.setPassword(passwordText.getText());
		user.setName(nameText.getText());
		user.setLatestOnline(user.getLatestOnline());
	}

	// �ı�Ի���Ĵ�С
	protected Point getInitialSize() {
		Point p = super.getInitialSize();
		p.x = 400;
		return p;
	}

	public IUser getUser() {
		return user;
	}

	public void setUser(IUser user) {
		this.user = user;
	}
}
