package cn.com.chengang.sms.db;

public class SqlServerOperate extends AbstractDbOperate {
	
}