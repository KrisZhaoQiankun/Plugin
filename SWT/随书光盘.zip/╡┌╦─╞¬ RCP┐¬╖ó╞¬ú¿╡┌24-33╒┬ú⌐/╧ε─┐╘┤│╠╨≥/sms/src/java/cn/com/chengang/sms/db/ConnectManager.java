package cn.com.chengang.sms.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.eclipse.jface.preference.IPreferenceStore;

import cn.com.chengang.sms.Activator;
import cn.com.chengang.sms.preferences.DBPreferencePage;

public class ConnectManager {
	private static Connection con;

	private ConnectManager() {}

	public static Connection getConnection() throws SQLException {
		if (con != null && !con.isClosed())// ��Ϊ����û�ر�
			return con;
		// ����ѡ������û������
		IPreferenceStore ps = Activator.getDefault().getPreferenceStore();
		String className = ps.getString(DBPreferencePage.CLASSNAME_KEY);
		String url = ps.getString(DBPreferencePage.URL_KEY);
		String username = ps.getString(DBPreferencePage.USERNAME_KEY);
		String password = ps.getString(DBPreferencePage.PASSWORD_KEY);
		// ����һ�����ݿ�����
		try {
			Class.forName(className);
			con = DriverManager.getConnection(url, username, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return con;
	}

	// �ṩһ�������ر�Connection�ķ���
	public static void closeConnection() {
		if (con == null)
			return;
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		con = null;
	}
}
