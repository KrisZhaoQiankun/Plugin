package cn.com.chengang.sms.score;

import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.PartInitException;

import cn.com.chengang.sms.model.Exam;
import cn.com.chengang.sms.model.Student;
import cn.com.chengang.sms.model.StudentScore;
import cn.com.chengang.sms.system.EditorPartAdapter;
import cn.com.chengang.sms.system.SmsContentProvider;
import cn.com.chengang.sms.system.SmsFactory;
import cn.com.chengang.sms.system.TableLabelProviderAdapter;

public class ScoreEditor extends EditorPartAdapter {
	private Label examLabel; // ��ͷ�Ŀ�����Ϣ����
	private TableViewer tv; // ��ʾ�ɼ��ı���

	public void init(IEditorSite site, IEditorInput input) throws PartInitException {
		super.init(site, input);
		setPartName(input.getName()); // ���±༭���ı���
	}

	public void createPartControl(Composite parent) {
		Composite topComp = new Composite(parent, SWT.NONE);
		topComp.setLayout(new FillLayout());
		createTableViewer(topComp);
		tv.setContentProvider(new SmsContentProvider());// ������
		tv.setLabelProvider(new TableViewerLabelProvider());// ��ǩ��
		// ���ڴ���ʱ��û�л�ò�ѯ���������Բ���setInpu
	}

	// ��������
	private void createTableViewer(Composite parent) {
		Composite tableComp = new Composite(parent, SWT.NONE);
		tableComp.setLayout(new GridLayout());
		examLabel = new Label(tableComp, SWT.NONE);
		examLabel.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		tv = new TableViewer(tableComp, SWT.MULTI | SWT.BORDER | SWT.FULL_SELECTION);
		Table table = tv.getTable();
		table.setLayoutData(new GridData(GridData.FILL_BOTH));
		table.setHeaderVisible(true); // ��ʾ��ͷ
		table.setLinesVisible(true); // ��ʾ������
		// ����TableViewer�е���
		TableLayout tLayout = new TableLayout();
		table.setLayout(tLayout);
		tLayout.addColumnData(new ColumnWeightData(10));
		new TableColumn(table, SWT.NONE).setText("ID��");
		tLayout.addColumnData(new ColumnWeightData(20));
		new TableColumn(table, SWT.NONE).setText("ѧ��");
		tLayout.addColumnData(new ColumnWeightData(20));
		new TableColumn(table, SWT.NONE).setText("�ɼ�");
	}

	// ���±�ͷ�Ŀ�����Ϣ������óɼ�����
	public void setExam(Exam exam) {
		// ���ñ�ͷ��Ϣ
		String s0 = exam.getName();
		String s1 = "    ʱ�䣺" + exam.getDate();
		String s2 = "    �γ̣�" + exam.getCourse().getName();
		String s3 = "    �༶��" + exam.getSchoolClass().getName();
		String s4 = "    �࿼��" + exam.getTeacher().getName();
		String str = s0 + s1 + s2 + s3 + s4;
		examLabel.setText(str);
		// ��óɼ�����
		tv.setInput(SmsFactory.getDbOperate().getStudentScore(exam));
	}

	// ��ǩ��
	private final static class TableViewerLabelProvider extends TableLabelProviderAdapter {
		public String getColumnText(Object element, int columnIndex) {
			StudentScore o = (StudentScore) element;
			switch (columnIndex) {
			case 0:
				return o.getId().toString();
			case 1:
				Student student = o.getStudent();
				if (student != null)
					return student.getName();
				return "";
			case 2:
				return String.valueOf(o.getScore());
			}
			return "";
		}
	}
}
