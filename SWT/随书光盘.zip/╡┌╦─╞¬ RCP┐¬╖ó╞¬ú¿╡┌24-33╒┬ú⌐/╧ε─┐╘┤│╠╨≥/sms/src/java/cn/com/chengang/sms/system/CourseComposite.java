package cn.com.chengang.sms.system;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.List;

import cn.com.chengang.sms.model.Course;

public class CourseComposite {
	private Group group;
	private List courseList; // �γ��б���������SWT���������Java����

	public CourseComposite(Composite parent, int style) {
		createCourseComp(parent, style);
	}

	// �����γ����
	private Composite createCourseComp(Composite comp, int style) {
		group = new Group(comp, style);
		group.setText("�γ�");
		group.setLayoutData(new GridData(GridData.FILL_BOTH));
		group.setLayout(new GridLayout(2, false));
		// �����γ�����е����
		courseList = new List(group, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		courseList.setLayoutData(new GridData(GridData.FILL_BOTH));
		// ���ť���
		Composite cmdComp = new Composite(group, SWT.NONE);
		cmdComp.setLayout(new RowLayout(SWT.VERTICAL));
		Button addButton = new Button(cmdComp, SWT.NONE);
		addButton.setText("����");
		addButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				CourseDialog dialog = new CourseDialog(null);
				if (dialog.open() == IDialogConstants.OK_ID) {
					Course course = dialog.getCourse();
					add(course);
				}
			}
		});
		Button removeButton = new Button(cmdComp, SWT.NONE);
		removeButton.setText("ɾ��");
		removeButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				if (courseList.getSelection().length != 0) {
					String sel = courseList.getSelection()[0];
					courseList.remove(sel);
				}
			}
		});
		return group;
	}

	// �����������ʾ/���صķ���
	public void setVisible(boolean enabled) {
		group.setVisible(false);
	}

	// ��courseList�����һ���γ�
	public void add(Course course) {
		if (courseList.indexOf(course.getName()) < 0) {
			String name = course.getName();
			courseList.add(name);
			courseList.setData(name, course);
		} else {
			MessageDialog.openError(null, "", "�Ѵ��ڵĿγ̲�������");
		}
	}

	// ȡ�ÿγ���
	public String[] getItems() {
		return courseList.getItems();
	}

	// ȡ�ÿγ���(key)��Ӧ�Ŀγ�
	public Course getData(String key) {
		return (Course) courseList.getData(key);
	}
}
