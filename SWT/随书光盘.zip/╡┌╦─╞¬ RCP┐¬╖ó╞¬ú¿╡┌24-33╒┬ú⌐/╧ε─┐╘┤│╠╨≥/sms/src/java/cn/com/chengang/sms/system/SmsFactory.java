package cn.com.chengang.sms.system;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.Platform;

import cn.com.chengang.sms.Activator;
import cn.com.chengang.sms.Constants;
import cn.com.chengang.sms.archive.ArchiveEditor;
import cn.com.chengang.sms.archive.ArchiveEditorInput;
import cn.com.chengang.sms.db.DbOperate;
import cn.com.chengang.sms.db.MysqlOperate;
import cn.com.chengang.sms.db.OracleOperate;
import cn.com.chengang.sms.db.SqlServerOperate;
import cn.com.chengang.sms.model.ITreeEntry;
import cn.com.chengang.sms.navigator.NavigatorEntry;

public class SmsFactory {
	public static List<ITreeEntry> createNavigatorEntryTree() {
		//���ɹ��ܵ������������
		NavigatorEntry t1 = new NavigatorEntry("���ݹ���");
		t1.setImage(ImagesContext.getImage(ImagesContext.STUDENT));
		NavigatorEntry t2 = new NavigatorEntry("�������");
		t2.setImage(ImagesContext.getImage(ImagesContext.REPORT));
		NavigatorEntry t3 = new NavigatorEntry("ϵͳ����");
		t3.setImage(ImagesContext.getImage(ImagesContext.SYSCONFIG));
		{
			NavigatorEntry c1 = new NavigatorEntry("��������");
			c1.setImage(ImagesContext.getImage(ImagesContext.NOTE));
			c1.setEditorInput(new ArchiveEditorInput());
			c1.setEditorId(ArchiveEditor.class.getName());
			t1.addChild(c1);
			NavigatorEntry c2 = new NavigatorEntry("�ɼ�����");
			c2.setImage(ImagesContext.getImage(ImagesContext.EDITING));
			t1.addChild(c2);
		}
		//������һ��������ͳһ����
		ArrayList<ITreeEntry> list = new ArrayList<ITreeEntry>();
		list.add(t1);
		list.add(t2);
		list.add(t3);
		list.addAll(getPluginNavigator());
		return list;
	}

	// ȡ��plugin.xml�е��Զ����㣬���뵽һ��List������
	private static List<ITreeEntry> getPluginNavigator() {
		List<ITreeEntry> result = new ArrayList<ITreeEntry>();
		// ��plugin.xml��ȡ���Զ�����չ��navigators����Ϣ
		IExtensionRegistry registry = Platform.getExtensionRegistry();
		IExtensionPoint extension = registry.getExtensionPoint("cn.com.chengang.sms.navigators");
		if (extension == null)
			return Collections.emptyList();
		// ȡ��plugin.xml������ʹ��navigators��չ���������Ϣ
		IConfigurationElement[] configElements = extension.getConfigurationElements();
		for (IConfigurationElement ce : configElements) {
			try {
				// ����������Ϣ��class���ԣ���������������ʵ��
				NavigatorEntry navigator = (NavigatorEntry) ce.createExecutableExtension("class");
				navigator.setName((String) ce.getAttribute("name"));
				String icon = (String) ce.getAttribute("icon");
				navigator.setImage(Activator.getImageDescriptor(icon).createImage());
				result.add(navigator);
			} catch (CoreException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	
	private static DbOperate db;
	public static DbOperate getDbOperate() {
		if (db == null) {
			int dbType = Constants.DBTYPE_MYSQL;// ����Ϊ�ӽ�������ȡֵ
			switch (dbType) {
			case Constants.DBTYPE_MYSQL:
				db = new MysqlOperate();
				break;
			case Constants.DBTYPE_ORACLE:
				db = new OracleOperate();
				break;
			case Constants.DBTYPE_SQLSERVER:
				db = new SqlServerOperate();
				break;
			default:
				db = new MysqlOperate();
				break;
			}
		}
		return db;
	}
}
