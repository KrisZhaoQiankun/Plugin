package cn.com.chengang.sms.navigator;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.actions.ActionGroup;

import cn.com.chengang.sms.Activator;
import cn.com.chengang.sms.system.Context;
import cn.com.chengang.sms.system.ILogonListener;
import cn.com.chengang.sms.system.ImagesContext;

public class NavigatorActionGroup extends ActionGroup {
	private Action logonAction = new LogonAction();
	private Action logoffAction = new LogoffAction();
	private Context ctx = Context.getInstance();
	private ILogonListener logonListener = new MyLogonListener();

	public NavigatorActionGroup() {
		ctx.addLogonListener(logonListener);
		setActionsEnabled(ctx.isLogon());// �����û��Ƿ��ѵ�¼���趨��ť��Ч״̬
	}

	private void setActionsEnabled(boolean logon) {
		logonAction.setEnabled(!logon);
		logoffAction.setEnabled(logon);
	}

	@Override
	public void dispose() {
		ctx.removeLogonListener(logonListener);
		super.dispose();
	}

	// ������ͼ��������ť
	@Override
	public void fillActionBars(IActionBars actionBars) {
		IToolBarManager toolBar = actionBars.getToolBarManager();
		toolBar.add(logonAction);
		toolBar.add(logoffAction);
	}

	// ��¼��ť
	private class LogonAction extends Action {
		public LogonAction() {
			setText("��¼");
			setHoverImageDescriptor(ImagesContext.getImageDescriptor(ImagesContext.LOGON));
		}

		public void run() {
			// �򿪵�¼����֤�û�����
			LogonDialog dialog = new LogonDialog(null);
			if (dialog.open() == IDialogConstants.OK_ID) {
				ctx.fireLogonEvent();// ֪ͨ����ҵ�¼��
				String s = "��¼��" + Context.getInstance().getCurrentUser().getName();
				Activator.getDefault().getStatusLine().setMessage(s);
			}
		}
	}

	// �˳���ť
	private class LogoffAction extends Action {
		public LogoffAction() {
			setText("�˳�");
			setHoverImageDescriptor(ImagesContext.getImageDescriptor(ImagesContext.LOGOFF));
		}

		public void run() {
			ctx.fireLogoffEvent();// ֪ͨ������˳���
			Activator.getDefault().getStatusLine().setMessage("");
		}
	}

	// ����һ������������Ҫ��Ϊ�˸��ݵ�¼�˳������ð�ť����Ч/��Ч״̬
	private class MyLogonListener implements ILogonListener {
		public void logon() {
			setActionsEnabled(true);
		}

		public void logoff() {
			setActionsEnabled(false);
		}
	}
}
