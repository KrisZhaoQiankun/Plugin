package cn.com.chengang.sms.system;
public interface ILogonListener {
    void logon();
    void logoff();
}
