package cn.com.chengang.sms.system;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.part.EditorPart;

import cn.com.chengang.sms.Activator;

public abstract class EditorPartAdapter extends EditorPart implements ILogonListener {
	public void doSave(IProgressMonitor monitor) {}

	public void doSaveAs() {}

	public void init(IEditorSite site, IEditorInput input) throws PartInitException {
		setSite(site);
		setInput(input);
		Context.getInstance().addLogonListener(this);
	}

	public boolean isDirty() {
		return false;
	}

	public boolean isSaveAsAllowed() {
		return false;
	}

	public void setFocus() {}

	@Override
	public void dispose() {
		Context.getInstance().removeLogonListener(this);
		super.dispose();
	}

	public void logoff() {
		IWorkbenchPage activePage = Activator.getDefault().getWorkbench().getActiveWorkbenchWindow().getActivePage();
		if (activePage != null) {
			// ���Թر�ǰ���棬�粻�ɹ������ٱ����ֱ�ӹر�
			boolean success = activePage.closeEditor(this, true);
			if (!success) {
				if (MessageDialog.openConfirm(null, "", "����༭��ʧ�ܣ��Ƿ�ֱ�ӹر�"))
					activePage.closeEditor(this, false);
			}
		}
	}

	public void logon() {}
}
