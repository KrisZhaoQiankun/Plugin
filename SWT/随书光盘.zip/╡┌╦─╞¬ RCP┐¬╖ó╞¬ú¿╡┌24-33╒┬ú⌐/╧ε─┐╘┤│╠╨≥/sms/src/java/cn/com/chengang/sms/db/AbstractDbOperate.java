package cn.com.chengang.sms.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import cn.com.chengang.sms.Constants;
import cn.com.chengang.sms.model.Course;
import cn.com.chengang.sms.model.Exam;
import cn.com.chengang.sms.model.Grade;
import cn.com.chengang.sms.model.IUser;
import cn.com.chengang.sms.model.SchoolClass;
import cn.com.chengang.sms.model.Student;
import cn.com.chengang.sms.model.StudentScore;
import cn.com.chengang.sms.model.Teacher;

public class AbstractDbOperate implements DbOperate {
	
	//���ݿ��Բ����õ��˿����µ�����ѧ����¼
	public List<StudentScore> getStudentScore(Exam exam) {
		Connection con = null;
		PreparedStatement sm = null;
		ResultSet rs = null;
		try {
			con = ConnectManager.getConnection();
			StringBuilder sb = new StringBuilder();
			sb.append("SELECT a.*,b.userId,b.password,b.name,b.latestonline,b.schoolclass_id ");
			sb.append("FROM studentscore a LEFT JOIN iuser b ON a.iuser_id=b.id ");
			sb.append("WHERE exam_id=" + exam.getId());
			System.out.println(sb.toString());
			sm = con.prepareStatement(sb.toString());
			rs = sm.executeQuery();
			List<StudentScore> list = new ArrayList<StudentScore>();
			while (rs.next()) {
				StudentScore studentScore = new StudentScore();
				studentScore.setId(new Long(rs.getInt("id")));
				studentScore.setExam(exam);
				studentScore.setScore(rs.getFloat("score"));
				{
					Student stu = new Student();
					stu.setId(new Long(rs.getLong("iuser_id")));
					stu.setUserId(rs.getString("userid"));
					stu.setPassword(rs.getString("password"));
					stu.setName(rs.getString("name"));
					stu.setLatestOnline(rs.getDate("latestOnline"));
					{// ����ѧ���İ༶����
						SchoolClass schoolClass = new SchoolClass();
						schoolClass.setId(new Long(rs.getInt("schoolclass_id")));
						stu.setSchoolclass(schoolClass);
					}
					studentScore.setStudent(stu);
				}
				list.add(studentScore);
			}
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs);
			close(sm);
			close(con);
		}
		return Collections.emptyList();
	}

	
	//���ݿ��Կγ̺Ϳ��԰༶�õ����ԡ����courseΪ�ձ�ʾȡ���пγ̿��ԣ�ͬ����
	//���schoolClassΪ�ձ�ʾȡ���а༶�Ŀ���
	public List<Exam> getExam(Course course, SchoolClass schoolClass) {
		Connection con = null;
		PreparedStatement sm = null;
		ResultSet rs = null;
		try {
			con = ConnectManager.getConnection();
			StringBuilder sb = new StringBuilder();
			sb.append("SELECT a.*, ");
			sb.append("b.name schoolclass_name,b.grade_id schoolclass_grade_id, ");
			sb.append("c.name course_name, ");
			sb.append("d.name iuser_name,d.userid iuser_userid,d.password iuser_password, d.latestonline iuser_latestonline ");
			sb.append("from exam a LEFT JOIN schoolclass b on a.schoolclass_id=b.id ");
			sb.append("LEFT JOIN course c ON  a.course_id =c.id ");
			sb.append("LEFT JOIN iuser d ON  a.iuser_id =d.id ");
			if (course != null && schoolClass != null)
				sb.append("where a.course_id = " + course.getId() + " and a.schoolclass_id = " + schoolClass.getId());
			else if (course == null && schoolClass != null)
				sb.append("where a.schoolclass_id = " + schoolClass.getId());
			else if (course != null && schoolClass == null)
				sb.append("where a.course_id = " + course.getId());
			System.out.println(sb.toString());
			sm = con.prepareStatement(sb.toString());
			rs = sm.executeQuery();
			List<Exam> list = new ArrayList<Exam>();
			while (rs.next()) {
				Exam exam = new Exam();
				//���������õ�ʵ������
				exam.setId(new Long(rs.getInt("id")));
				exam.setName(rs.getString("name"));
				exam.setDate(rs.getDate("date"));
				{
					SchoolClass o = new SchoolClass();
					o.setId(new Long(rs.getInt("schoolclass_id")));
					o.setName(rs.getString("schoolclass_name"));
					Grade o2 = new Grade();
					o2.setId(new Long(rs.getInt("schoolclass_grade_id")));
					o.setGrade(o2);
					exam.setSchoolClass(o);
				}
				{
					Course o = new Course();
					o.setId(new Long(rs.getInt("course_id")));
					o.setName(rs.getString("course_name"));
					exam.setCourse(o);
				}
				{
					Teacher o = new Teacher();
					o.setId(new Long(rs.getInt("iuser_id")));
					o.setUserId(rs.getString("iuser_userid"));
					o.setPassword(rs.getString("iuser_password"));
					o.setName(rs.getString("iuser_name"));
					o.setLatestOnline(rs.getDate("iuser_latestonline"));
					exam.setTeacher(o);
				}
				list.add(exam);
			}
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs);
			close(sm);
			close(con);
		}
		return Collections.emptyList();
	}

	// �޸��û���¼
	public boolean modifyUser(IUser user) {
		Connection con = null;
		PreparedStatement sm = null;
		ResultSet rs = null;
		try {
			con = ConnectManager.getConnection();
			String sql = "update iuser set userid=?,password=?,name=?,latestOnline=?,schoolclass_id=? where id=?";
			sm = con.prepareStatement(sql);
			sm.setString(1, user.getUserId());
			sm.setString(2, user.getPassword());
			sm.setString(3, user.getName());
			Date latestOnline = user.getLatestOnline();
			if (latestOnline != null) {
				long dateValue = latestOnline.getTime();
				sm.setDate(4, new java.sql.Date(dateValue));
			}
			sm.setInt(6, user.getId().intValue());
			if (user instanceof Student) {
				SchoolClass schoolClass = ((Student) user).getSchoolclass();
				if (schoolClass == null)
					sm.setNull(5, java.sql.Types.BIGINT);
				else
					sm.setInt(5, schoolClass.getId().intValue());
			} else {
				sm.setNull(5, java.sql.Types.BIGINT);
			}
			sm.executeUpdate();
			// �������ʦ��Ҫ�������Ŀγ����
			if (user instanceof Teacher) {
				con.setAutoCommit(false); // ��ֹ�Զ��ύ����
				sm.setNull(5, java.sql.Types.BIGINT);
				sm.addBatch("delete from iuser_course where iuser_id=" + user.getId());
				Set<Course> set = ((Teacher) user).getCourses();
				for (Course course : set)
					sm.addBatch("insert into iuser_course values (" + user.getId() + "," + course.getId() + ")");
				sm.executeBatch();
				con.commit(); // �ύ
			}
		} catch (SQLException e) {
			e.printStackTrace();
			// ������쳣��ع�
			try {
				con.rollback(); 
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			return false;
		} finally {
			close(rs);
			close(sm);
			close(con);
		}
		return true;
	}

	//�õ����а༶�ļ�¼
	public List<SchoolClass> getAllSchoolClass() {
		Connection con = null;
		PreparedStatement sm = null;
		ResultSet rs = null;
		try {
			con = ConnectManager.getConnection();
			sm = con.prepareStatement("SELECT * from schoolclass");
			rs = sm.executeQuery();
			List<SchoolClass> list = new ArrayList<SchoolClass>();
			while (rs.next()) {
				SchoolClass schoolClass = new SchoolClass();
				schoolClass.setId(new Long(rs.getInt("id")));
				schoolClass.setName(rs.getString("name"));
				// �����꼶����
				Grade grade = new Grade();
				grade.setId(new Long(rs.getInt("grade_id")));
				schoolClass.setGrade(grade);
				list.add(schoolClass);
			}
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs);
			close(sm);
			close(con);
		}
		return Collections.emptyList();
	}
	
	// �õ����пγ̼�¼
	public List<Course> getCourses() {
		Connection con = null;
		PreparedStatement sm = null;
		ResultSet rs = null;
		try {
			con = ConnectManager.getConnection();
			String sql = "SELECT * from course";
			sm = con.prepareStatement(sql);
			rs = sm.executeQuery();
			List<Course> list = new ArrayList<Course>();
			while (rs.next()) {
				Course course = new Course();
				course.setId(new Long(rs.getInt("id")));
				course.setName(rs.getString("name"));
				list.add(course);
			}
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs);
			close(sm);
			close(con);
		}
		return Collections.emptyList();
	}
	
	//����һ���û���¼
	public boolean insertUser(IUser user) {
		Connection con = null;
		PreparedStatement sm = null;
		ResultSet rs = null;
		try {
			con = ConnectManager.getConnection();
			if (getUser(user.getUserId()) != null)//������ݿ��userId�Ƿ�����
				return false;
			String sql = "insert into iuser (type,userid,password,name,schoolclass_id) VALUES (?,?,?,?,?);";
			sm = con.prepareStatement(sql);
			sm.setString(2, user.getUserId());
			sm.setString(3, user.getPassword());
			sm.setString(4, user.getName());
			if (user instanceof Student) {
				sm.setString(1, Constants.IUSER_STUDENT_TYPE);
				SchoolClass schoolClass = ((Student) user).getSchoolclass();
				if (schoolClass == null)
					sm.setNull(5, java.sql.Types.BIGINT);
				else
					sm.setInt(5, schoolClass.getId().intValue());
				sm.execute();
			} else if (user instanceof Teacher) {
				sm.setString(1, Constants.IUSER_TEACHER_TYPE);
				sm.setNull(5, java.sql.Types.BIGINT);
				sm.execute();//���û����ļ�¼����
				rs = sm.executeQuery("select id from iuser where userid='" + user.getUserId() + "'");
				rs.next();
				int iuser_id = rs.getInt(1);
				//�������ʦ��Ҫ�������Ŀγ����
				for (Course course : ((Teacher) user).getCourses()) {
					sql = "insert into iuser_course values (" + iuser_id + "," + course.getId() + ")";
					sm.addBatch(sql);
				}
				sm.executeBatch();
			}
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				con.rollback(); //������쳣��ع�
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		} finally {
			close(rs);
			close(sm);
			close(con);
		}
		return false;
	}
	
	// ɾ��һ���û���¼
	public boolean removeUser(IUser user) {
		Connection con = null;
		Statement sm = null;
		ResultSet rs = null;
		boolean result = true;
		try {
			// ��������ķ�����
			// ��1��setAutoCommit(Boolean autoCommit):�����Ƿ��Զ��ύ����
			// ��2��commit();�ύ����
			// ��3��rollback();��������
			con = ConnectManager.getConnection();
			con.setAutoCommit(false); // ��ֹ�Զ��ύ����
			sm = con.createStatement();
			sm.addBatch("delete from iuser where id=" + user.getId());
			if (user instanceof Teacher)// ��ʦ���û���Ҫɾ����γ����ӱ��ļ�¼
				sm.addBatch("delete from iuser_course where iuser_id=" + user.getId());
			sm.executeBatch();
			con.commit(); // �ύ
		} catch (SQLException e) {
			result = false;
			e.printStackTrace();
			try {
				con.rollback(); // ������쳣��ع�
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		} finally {
			close(rs);
			close(sm);
			close(con);
		}
		return result;
	}
	
	// ���ݷ�ҳ��Ϣ��ȡ����Ӧ���û���¼
	public List<IUser> getUsers(QueryInfo qi) {
		Connection con = null;
		Statement sm = null;
		ResultSet rs = null;
		try {
			con = ConnectManager.getConnection();
			sm = con.createStatement();
			// �õ��ܼ�¼��
			rs = sm.executeQuery("select count(id) from iuser");
			rs.next();
			qi.rsCount = rs.getInt(1);
			if (qi.rsCount == 0)// ����0��ʾû�м�¼
				return Collections.emptyList();
			// �����ҳ��
			if (qi.rsCount % qi.pageSize == 0)
				qi.pageCount = qi.rsCount / qi.pageSize;
			else
				qi.pageCount = (qi.rsCount / qi.pageSize) + 1;
			// �����ʼλ�ã� (��ǰҳ��-1)*ÿҳ��¼��
			int start = (qi.currentPage - 1) * qi.pageSize;
			rs = sm.executeQuery("select * from iuser limit " + start + "," + qi.pageSize);
			List<IUser> list = new ArrayList<IUser>(qi.pageSize);
			while (rs.next()) {
				IUser user = createUserFromRs(rs);
				user.setId(new Long(rs.getLong("id")));
				user.setUserId(rs.getString("userid"));
				user.setPassword(rs.getString("password"));
				user.setName(rs.getString("name"));
				user.setLatestOnline(rs.getDate("latestOnline"));
				list.add(user);
			}
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs);
			close(sm);
			close(con);
		}
		return Collections.emptyList();
	}
	
	// �����û����õ��û������緵��null���ʾ���û�������
	public IUser getUser(String userId) {
		Connection con = null;
		Statement sm = null;
		ResultSet rs = null;
		try {
			con = ConnectManager.getConnection();
			sm = con.createStatement();
			rs = sm.executeQuery("select * from iuser where userId='" + userId + "'");
			if (rs.next()) {
				IUser user = createUserFromRs(rs);
				// ���������õ�ʵ������
				user.setId(new Long(rs.getLong("id")));
				user.setUserId(userId);
				user.setPassword(rs.getString("password"));
				user.setName(rs.getString("name"));
				user.setLatestOnline(rs.getDate("latestOnline"));
				return user;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs);
			close(sm);
			close(con);
		}
		return null;
	}

	// �������ݿ��¼rs�е�Type�ֶ�ֵ������ʵ�ʵ��û����ͣ������������е�ֵ
	private IUser createUserFromRs(ResultSet rs) throws SQLException {
		String type = rs.getString("type");// ����typeֵ�жϴ˼�¼����ʲô��
		if (type.equalsIgnoreCase(Constants.IUSER_TEACHER_TYPE)) {
			Teacher o = new Teacher();
			Long iuser_id = new Long(rs.getLong("id"));
			o.setCourses(getCourses(iuser_id));
			return o;
		} else if (type.equalsIgnoreCase(Constants.IUSER_STUDENT_TYPE)) {
			Student o = new Student();
			Long schoolclass_id = new Long(rs.getLong("schoolclass_id"));
			o.setSchoolclass(getSchoolclass(schoolclass_id));
			return o;
		}
		return null;
	}

	// �����û���id�ֶΣ��õ�����Ӧ�Ŀγ̼�¼�����᷵��nullֵ
	public Set<Course> getCourses(Long iuser_id) {
		Connection con = null;
		Statement sm = null;
		ResultSet rs = null;
		try {
			con = ConnectManager.getConnection();
			sm = con.createStatement();
			// ���û��γ����ӱ��õ����û���Ӧ�����пγ�IDֵ
			String subSql = "select course_id from iuser_course WHERE iuser_id=" + iuser_id;
			// �õ���ЩIDֵ��Ӧ�Ŀγ̼�¼
			String sql = "SELECT * from course where id in (" + subSql + ")";
			rs = sm.executeQuery(sql);
			Set<Course> set = new HashSet<Course>();
			while (rs.next()) {
				Course course = new Course();
				course.setId(new Long(rs.getInt("id")));
				course.setName(rs.getString("name"));
				set.add(course);
			}
			return set;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs);
			close(sm);
			close(con);
		}
		return Collections.emptySet();
	}

	// ���ݰ༶��id�õ��༶���󡣷���null��ʾ�����ڶ�Ӧ�İ༶
	public SchoolClass getSchoolclass(Long id) {
		Connection con = null;
		PreparedStatement sm = null;
		ResultSet rs = null;
		try {
			con = ConnectManager.getConnection();
			sm = con.prepareStatement("SELECT * from schoolclass where id=" + id);
			rs = sm.executeQuery();
			if (rs.next()) {
				SchoolClass schoolClass = new SchoolClass();
				schoolClass.setId(new Long(rs.getInt("id")));
				schoolClass.setName(rs.getString("name"));
				{// �����꼶����
					Grade grade = new Grade();
					grade.setId(new Long(rs.getInt("grade_id")));
					schoolClass.setGrade(grade);
				}
				return schoolClass;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs);
			close(sm);
			close(con);
		}
		return null;
	}

	// �ر�ResultSet����
	void close(ResultSet rs) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			rs = null;
		}
	}

	// �ر�Statement����
	void close(Statement sm) {
		if (sm != null) {
			try {
				sm.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			sm = null;
		}
	}

	// �ر�Connection����
	void close(Connection con) {}
}
