package cn.com.chengang.sms.archive.wizard;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;

import cn.com.chengang.sms.model.Course;
import cn.com.chengang.sms.model.Teacher;
import cn.com.chengang.sms.system.CourseComposite;

public class CoursesPage extends WizardPage {
    private CourseComposite courseComp; //�γ����

    protected CoursesPage(String pageName) {
        super(pageName);
    }

    public void createControl(Composite parent) {
        setTitle("�����û�");
        setMessage("������ʦ���̵Ŀγ�", INFORMATION);
        Composite topComp = new Composite(parent, SWT.NONE);
        topComp.setLayout(new GridLayout());
        courseComp = new CourseComposite(topComp, SWT.NONE);
        setControl(topComp);
    }

    //������е�ֵ���´����Teacher����
    public void getValue(Teacher teacher) {
    	teacher.clearCourses();
        for (String key : courseComp.getItems()) {
            Course course = courseComp.getData(key);
            teacher.addCourse(course);
        }
    }
}
