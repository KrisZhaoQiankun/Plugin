package cn.com.chengang.myplugin;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;

public class LanguageDialog extends Dialog {
	protected LanguageDialog(Shell parentShell) {
		super(parentShell);
	}

	protected Control createDialogArea(Composite parent) {
		Composite topComp = new Composite(parent, SWT.NONE);
		topComp.setLayout(new RowLayout());
		Button button1 = new Button(topComp, SWT.NONE);
		// button1.setText("ȷ��");
		button1.setText(Messages.getString("LanguageDialog.ok"));
		Button button2 = new Button(topComp, SWT.NONE);
		// button2.setText("ɾ��");
		button2.setText(Messages.getString("LanguageDialog.remove"));
		return topComp;
	}
}
