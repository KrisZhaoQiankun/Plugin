package cn.com.chengang.swt;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class GridData1 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		shell.setLayout(new GridLayout(2, false));
		new Button(shell, SWT.NONE).setText("b1");
		new Button(shell, SWT.NONE).setText("button2");

		// ����һ��GridData������b3��ť��ռ���еĿռ�
		Button b3 = new Button(shell, SWT.NONE);
		GridData gridData = new GridData();
//		GridData gridData = new GridData(GridData.FILL_HORIZONTAL);
		gridData.horizontalSpan = 2;
		b3.setLayoutData(gridData);
		b3.setText("b3");

		new Button(shell, SWT.NONE).setText("button4");
		new Button(shell, SWT.NONE).setText("button5");
		
//		Button button5 = new Button(shell, SWT.NONE);
//		GridData gridData2 = new GridData(GridData.FILL_HORIZONTAL);
//		button5.setLayoutData(gridData2);
//		button5.setText("button5");

		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
