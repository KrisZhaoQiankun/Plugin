package cn.com.chengang.form;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.forms.events.HyperlinkAdapter;
import org.eclipse.ui.forms.events.HyperlinkEvent;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Hyperlink;
import org.eclipse.ui.forms.widgets.TableWrapLayout;

public class Hyperlink1 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		shell.setLayout(new FillLayout());
		FormToolkit toolkit = new FormToolkit(display);
		Composite comp = toolkit.createComposite(shell);
		comp.setLayout(new TableWrapLayout());
		Hyperlink link = toolkit.createHyperlink(comp, "���ڴ���Ի", SWT.WRAP);
		link.setHref("http://www.chengang.com.cn");
		link.addHyperlinkListener(new HyperlinkAdapter() {
			public void linkActivated(HyperlinkEvent e) {
				// ��ӡ����ǡ����ڴ���Ի:http://www.chengang.com.cn��
				System.out.println(e.getLabel() + ":" + e.getHref());
			}
		});

		// HyperlinkGroup linkgroup = toolkit.getHyperlinkGroup();
		// linkgroup.add(link1);
		// linkgroup.add(link2);
		// linkgroup.add(link3);
		// // ��ý���ʱ��ʾ��ɫ����
		// linkgroup.setActiveBackground(display.getSystemColor(SWT.COLOR_RED));
		// // �������²���ʾ�»���
		// linkgroup.setHyperlinkUnderlineMode(HyperlinkGroup.UNDERLINE_NEVER);
		//
		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
