package cn.com.chengang.databinding;

import java.util.Arrays;

import org.eclipse.jface.internal.databinding.provisional.DataBindingContext;
import org.eclipse.jface.internal.databinding.provisional.description.Property;
import org.eclipse.jface.internal.databinding.provisional.observable.list.WritableList;
import org.eclipse.jface.internal.databinding.provisional.swt.SWTProperties;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class JFaceDataBinding7 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		shell.setLayout(new RowLayout());
		final People bean = new People();// ����
		Button button = new Button(shell, SWT.NONE);
		button.setText("��ӡ����");
		button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				System.out.println("---------------------------------");
				System.out.println("name=" + bean.getName());
				System.out.println("age=" + bean.getAge());
				System.out.println("sex=" + bean.isSex());
				System.out.println("interests=" + Arrays.toString(bean.getInterests().toArray()));
			}
		});

		// �������
		Combo combo = new Combo(shell, SWT.BORDER);
		// �󶨳�ʼ����
		DataBindingContext ctx = DataBindingContextFactory.createContext(shell);
		WritableList ageList = new WritableList(String.class);
		ageList.add("0");
		ageList.add("10");
		ageList.add("20");
		ageList.add("30");
		ctx.bind(new Property(combo, SWTProperties.ITEMS), ageList, null);
		ageList.add("100"); // �Ժ󻹿����ټӽ������ʵ�ַ�ӳ��������
		combo.remove("100");// ����ӽ���ɾ��ĳ�ageListҲ�����ɾ�����
		// ��ѡ��
		ctx.bind(new Property(combo, SWTProperties.SELECTION), new Property(bean, "age"), null);
		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

}
