package cn.com.chengang.jface.dialog.loopprogressdialog;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.ImageLoader;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class AnimationGIFClient {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		shell.setLayout(new GridLayout());

		ImageLoader imageLoader = new ImageLoader();
		// imageLoader.load("icons/animation1.gif");
		// imageLoader.load("icons/animation4.gif");
		// imageLoader.load("icons/animation5.gif");
		// imageLoader.load("icons/animation2.gif");
		imageLoader.load("icons/animation3.gif");

		final AnimationGIF gif = new AnimationGIF(shell, SWT.BORDER, imageLoader);
		gif.setLayoutData(new GridData(GridData.FILL_BOTH));

		// ��ť�����
		Composite comp = new Composite(shell, SWT.NONE);
		comp.setLayout(new RowLayout());
		final Button b1 = new Button(comp, SWT.NONE);
		b1.setText("STOP");
		b1.addSelectionListener(new SelectionAdapter() {
			private String str = "STOP";

			public void widgetSelected(SelectionEvent e) {
				if (str.equals("RUN")) {
					gif.run();
					str = "STOP";
				} else {
					gif.stop();
					str = "RUN";
				}
				b1.setText(str);
			}
		});
		// -----------------END------------------------
		shell.layout();
		shell.open();

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
