package cn.com.chengang.jface.treeviewer;

import java.util.List;

import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class TreeViewer1 {
	public static void main(String[] args) {
		new TreeViewer1().open();
	}

	public void open() {
		final Display display = new Display();
		final Shell shell = new Shell();
		shell.setSize(200, 300);
		// -----------������Ĵ���-------------------
		shell.setLayout(new FillLayout());
		TreeViewer tv = new TreeViewer(shell, SWT.BORDER);
		tv.setContentProvider(new TreeViewerContentProvider());
		tv.setLabelProvider(new TreeViewerLableProvider());
		// ��TableViewerһ�������ݵ����Ҳ��setInput����
		List<CountryEntity> input = DataFactory.createTreeData();
		tv.setInput(input);
		// -----------END------------------
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
