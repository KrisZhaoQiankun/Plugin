package cn.com.chengang.swt;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class FormData1 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		shell.setLayout(new FormLayout());

		Button button1 = new Button(shell, SWT.NONE);
		button1.setText("button1");
		FormData formData = new FormData();
		button1.setLayoutData(formData);

		Button button2 = new Button(shell, SWT.NONE);
		button2.setText("button2");
		FormData formData2 = new FormData(200, 50);// button2���200����50��
		button2.setLayoutData(formData2);
		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
