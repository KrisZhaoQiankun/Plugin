package cn.com.chengang.swt;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

public class Listener1 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		shell.setLayout(new FillLayout());
		Button button = new Button(shell, SWT.NONE);
		button.setText("OK");
		Listener listener = new Listener() {
			public void handleEvent(Event event) {
				if (event.type == SWT.Selection)
					System.out.println("����");
				if (event.type == SWT.MouseEnter)
					System.out.println("������");
			}
		};
		button.addListener(SWT.Selection, listener);
		button.addListener(SWT.MouseEnter, listener);
		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
