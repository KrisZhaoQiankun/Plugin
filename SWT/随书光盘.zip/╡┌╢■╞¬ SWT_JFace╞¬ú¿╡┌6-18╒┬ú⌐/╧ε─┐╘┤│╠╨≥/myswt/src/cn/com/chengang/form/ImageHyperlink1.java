package cn.com.chengang.form;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.forms.events.HyperlinkAdapter;
import org.eclipse.ui.forms.events.HyperlinkEvent;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ImageHyperlink;

public class ImageHyperlink1 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(200, 150);
		// ---------���������е������������-------------
		shell.setLayout(new RowLayout());
		FormToolkit toolkit = new FormToolkit(display);
		ImageHyperlink form = toolkit.createImageHyperlink(shell, SWT.WRAP);
		form.setText("���ڴ���Ի");
		form.setHref("http://www.chengang.com.cn");
		form.setImage(new Image(display, "icons/project.gif"));
		form.addHyperlinkListener(new HyperlinkAdapter() {
			public void linkActivated(HyperlinkEvent e) {
				// ��ӡ����ǡ����ڴ���Ի:http://www.chengang.com.cn��
				System.out.println(e.getLabel() + ":" + e.getHref());
			}
		});
		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
