package cn.com.chengang.databinding;

import java.util.Collections;
import java.util.List;

public class People {
	private String name; // ����
	private boolean sex; // �Ա� true�У�flaseŮ
	private int age; // ����
	private List<String> interests;// ��Ȥ
	private List<City> cities;// �������������ĳ���

	public String getName() {
		return name;
	}

	public void setName(String string) {
		name = string;
	}

	public boolean isSex() {
		return sex;
	}

	public void setSex(boolean sex) {
		this.sex = sex;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int i) {
		age = i;
	}

	public List<String> getInterests() {
		if (interests == null)
			return Collections.emptyList();
		return interests;
	}

	public void setInterests(List<String> interests) {
		this.interests = interests;
	}

	public List<City> getCities() {
		if (cities == null)
			return Collections.emptyList();
		return cities;
	}

	public void setCities(List<City> cities) {
		this.cities = cities;
	}

}
