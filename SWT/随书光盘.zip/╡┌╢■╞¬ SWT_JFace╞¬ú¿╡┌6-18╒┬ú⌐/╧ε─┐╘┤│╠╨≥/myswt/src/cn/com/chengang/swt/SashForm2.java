package cn.com.chengang.swt;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class SashForm2 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		SashForm sashForm = new SashForm(shell, SWT.NONE);
		new Text(sashForm, SWT.BORDER).setText("��");

		SashForm rightSashForm = new SashForm(sashForm, SWT.VERTICAL);// ��Ƕһ���ָ����
		new Text(rightSashForm, SWT.BORDER).setText("����");
		new Text(rightSashForm, SWT.BORDER).setText("����");

		sashForm.setWeights(new int[] { 1, 3 });
		rightSashForm.setWeights(new int[] { 5, 2 });
		sashForm.setBounds(10, 10, 206, 168);
		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
