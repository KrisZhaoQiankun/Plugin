package cn.com.chengang.form;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.forms.widgets.ColumnLayout;
import org.eclipse.ui.forms.widgets.FormToolkit;

public class ColumnLayout1 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		shell.setLayout(new FillLayout());
		FormToolkit toolkit = new FormToolkit(display);
		Composite comp = toolkit.createComposite(shell);
		ColumnLayout layout = new ColumnLayout();
		// RowLayout layout = new RowLayout();
		// layout.maxNumColumns = 4;
		// layout.minNumColumns = 1;
		comp.setLayout(layout);
		toolkit.createButton(comp, "1", SWT.PUSH);
		toolkit.createButton(comp, "2", SWT.PUSH);
		toolkit.createButton(comp, "3", SWT.PUSH);
		toolkit.createButton(comp, "4", SWT.PUSH);
		toolkit.createButton(comp, "5", SWT.PUSH);
		toolkit.createButton(comp, "6", SWT.PUSH);
		toolkit.createButton(comp, "7", SWT.PUSH);
		toolkit.createButton(comp, "8", SWT.PUSH);
//		toolkit.createButton(comp, "9", SWT.PUSH);
//		toolkit.createButton(comp, "10", SWT.PUSH);
		//
		toolkit.paintBordersFor(comp);

		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
