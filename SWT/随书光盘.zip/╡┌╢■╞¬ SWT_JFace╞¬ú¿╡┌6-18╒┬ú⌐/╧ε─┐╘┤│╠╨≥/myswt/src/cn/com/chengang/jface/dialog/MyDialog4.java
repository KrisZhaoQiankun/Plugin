package cn.com.chengang.jface.dialog;

import java.io.IOException;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.DialogSettings;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.IDialogSettings;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class MyDialog4 extends Dialog {
	private Human human;
	private Text nameText;
	private Text oldText;
	private Button ggButton, mmButton;

	public MyDialog4(Shell parentShell) {
		super(parentShell);
	}

	public Human getInput() {
		return this.human;
	}

	public void setInput(Human human) {
		this.human = human;
	}

	// ����������ﹹ��Dialog�еĽ�������
	protected Control createDialogArea(Composite parent) {
		Composite topComp = new Composite(parent, SWT.NONE);
		topComp.setLayout(new GridLayout(2, false));
		new Label(topComp, SWT.NONE).setText("������");
		nameText = new Text(topComp, SWT.BORDER);
		nameText.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		new Label(topComp, SWT.NONE).setText("���䣺");
		oldText = new Text(topComp, SWT.BORDER);// ʡ����ֻ��������ֵ������
		oldText.setLayoutData(new GridData(20, -1));

		new Label(topComp, SWT.NONE).setText("�Ա�");
		Composite c = new Composite(topComp, SWT.None);
		c.setLayout(new RowLayout());
		ggButton = new Button(c, SWT.RADIO);
		ggButton.setText("��");
		mmButton = new Button(c, SWT.RADIO);
		mmButton.setText("Ů");

		// ���û���ֶ����ó�ʼֵ����ȡ����ǰ�������ļ����ֵ���µ�Human����
		if (human == null)
			restoreState();
		
		if (human != null) {
			nameText.setText(human.getName() == null ? "" : human.getName());
			oldText.setText(String.valueOf(human.getOld()));
			ggButton.setSelection(human.isSex());
			mmButton.setSelection(!human.isSex());
		}
		return topComp;
	}

	protected void buttonPressed(int buttonId) {
		if (buttonId == IDialogConstants.OK_ID) {// �������ȷ����ť����ֵ���浽Human������
			if (human == null)
				human = new Human();
			human.setName(nameText.getText());
			human.setOld(Integer.parseInt(oldText.getText()));
			human.setSex(ggButton.getSelection());
			saveState();//��Human���󱣴浽�ļ�
		}
		super.buttonPressed(buttonId);
	}

	// ��Human���󱣴浽�ļ�
	public void saveState() {
		if (human == null)
			return;
		IDialogSettings topSettings = getTopSettings();
		IDialogSettings settings = topSettings.getSection("MyDialog4");
		if (settings == null)
			settings = topSettings.addNewSection("MyDialog4");
		settings.put("name", human.getName());
		settings.put("old", human.getOld());
		settings.put("sex", human.isSex());
		try {
			topSettings.save("icons/system.xml");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// ȡ�������ֵ�����µ�Human����
	public void restoreState() {
		IDialogSettings topSettings = getTopSettings();
		IDialogSettings settings = topSettings.getSection("MyDialog4");
		if (settings == null)
			return;
		if (human == null)
			human = new Human();
		human.setName(settings.get("name"));
		human.setOld(settings.getInt("old"));
		human.setSex(settings.getBoolean("sex"));
	}

	// ȡ�ö�����IDialogSettings
	public IDialogSettings getTopSettings() {
		IDialogSettings topSettings = new DialogSettings("system");
		try {
			topSettings.load("icons/system.xml");
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return topSettings;
	}
}
