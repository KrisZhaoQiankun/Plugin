package cn.com.chengang.swt;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class FormLayout1 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		FormLayout formLayout = new FormLayout();
		formLayout.marginWidth = 100; // ��߾࣬��λ������
		formLayout.marginHeight = 50; // �ϱ߾�
		shell.setLayout(formLayout);
		new Button(shell, SWT.NONE).setText("button1");
		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
