package cn.com.chengang.swt;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class FormAttachment1 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		shell.setLayout(new FormLayout());
		Button button = new Button(shell, SWT.NONE);
		button.setText("button");
		FormData formData = new FormData();
		// ��ť�Ķ��ˣ�formData.top����shell�����Ŀհױ߾���shell��������հ׳��ȵ�60%
		formData.top = new FormAttachment(60, 0);
		button.setLayoutData(formData);
		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
