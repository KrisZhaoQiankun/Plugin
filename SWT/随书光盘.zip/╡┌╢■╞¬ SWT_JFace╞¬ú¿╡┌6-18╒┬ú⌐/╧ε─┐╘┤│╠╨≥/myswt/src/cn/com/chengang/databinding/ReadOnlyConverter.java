package cn.com.chengang.databinding;

import org.eclipse.jface.internal.databinding.provisional.conversion.IConverter;

public class ReadOnlyConverter implements IConverter {
	private Object from, to;

	public ReadOnlyConverter(Object from, Object to) {
		this.from = from;
		this.to = to;
	}

	public Object convert(Object fromObject) {
		return null;
	}

	public Object getFromType() {
		return from;
	}

	public Object getToType() {
		return to;
	}
}
