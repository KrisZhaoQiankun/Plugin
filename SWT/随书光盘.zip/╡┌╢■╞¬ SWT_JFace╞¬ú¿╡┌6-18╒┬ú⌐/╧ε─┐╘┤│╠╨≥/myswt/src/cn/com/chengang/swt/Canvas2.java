package cn.com.chengang.swt;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class Canvas2 {
	private static Image image;

	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		shell.setLayout(new RowLayout());

		// SWT.H_SCROLL|SWT.V_SCROLLʽ�����ڻ�������ʾ������
		final Canvas canvas = new Canvas(shell, SWT.BORDER);
		// ����canvas���ػ��¼�
		canvas.addPaintListener(new PaintListener() {
			public void paintControl(final PaintEvent event) {
				// ��ͼ����ʾ��canvas�ϣ���10,10����λͼ�����ϽǾ�canvas���Ͻǵľ���
				if (image != null) {
					event.gc.drawImage(image, 10, 10);
				}
			}
		});

		final Image refreshImage = new Image(display, "icons/refresh.gif");
		final Image nextImage = new Image(display, "icons/next.gif");

		Button button1 = new Button(shell, SWT.NONE);
		button1.setText("ͼƬ1");
		button1.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				image = refreshImage;
				canvas.redraw();
			}
		});
		Button button2 = new Button(shell, SWT.NONE);
		button2.setText("ͼƬ2");
		button2.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				image = nextImage;
				canvas.redraw();
			}
		});
		Button clearButton = new Button(shell, SWT.NONE);
		clearButton.setText("���ͼ��");
		clearButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				image = null;
				canvas.redraw();
			}
		});
		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
