package cn.com.chengang.jface.dialog.loopprogressdialog;


public interface IProgressDialogRunnable {
	void run(BooleanFlag stopFlag);
}
