package cn.com.chengang.jface.dialog.loopprogressdialog;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.ImageLoader;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import cn.com.chengang.swt.SWTUtils;

public class LoopImageDialog {
	private Shell parentShell;
	public BooleanFlag stopFlag = new BooleanFlag();

	protected LoopImageDialog(Shell parentShell) {
		this.parentShell = parentShell;
	}

	public void run(boolean cancelable, final IProgressDialogRunnable runnable) {
		new Thread() {
			public void run() {
				runnable.run(stopFlag);
			}
		}.start();
		showDialog();
	}

	private void showDialog() {
		final Display display = Display.getDefault();
		Shell shell = new Shell(parentShell);
		shell.setSize(250, 180);
		SWTUtils.setCenter(shell); // ʹ��shell����
		shell.setLayout(new FillLayout());
		// ��Shell������ʾһ������GIF
		final ImageLoader imageLoader = new ImageLoader();
		imageLoader.load("icons/animation2.gif");
		new AnimationGIF(shell, SWT.BORDER, imageLoader);
		// �������ڡ�Shell��Dialog��ͬ������open��������֮���̳�ִ����������
		shell.open();
		while (!shell.isDisposed()) {
			if (stopFlag.getFlag())
				shell.dispose();
			if (!display.readAndDispatch())
				display.sleep();
		}
		stopFlag.setFlag(true);
	}
}
