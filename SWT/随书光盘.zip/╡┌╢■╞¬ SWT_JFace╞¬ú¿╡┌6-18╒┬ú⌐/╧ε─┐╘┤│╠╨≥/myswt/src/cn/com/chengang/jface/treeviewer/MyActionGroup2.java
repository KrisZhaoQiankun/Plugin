package cn.com.chengang.jface.treeviewer;

import java.util.Iterator;
import java.util.List;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.ui.actions.ActionGroup;
import org.eclipse.ui.dialogs.ContainerCheckedTreeViewer;

public class MyActionGroup2 extends ActionGroup {
	private ContainerCheckedTreeViewer tv;

	public MyActionGroup2(ContainerCheckedTreeViewer tv) {
		this.tv = tv;
	}

	public void fillContextMenu(IMenuManager mgr) {
		MenuManager menuManager = (MenuManager) mgr;
		menuManager.add(new SelectAllAction());
		menuManager.add(new RemoveEntryAction());
		Tree tree = tv.getTree();
		Menu menu = menuManager.createContextMenu(tree);
		tree.setMenu(menu);
	}

	private class SelectAllAction extends Action {
		public SelectAllAction() {
			setText("��ѡ��ǰ���������ӽ��");
		}

		public void run() {
			IStructuredSelection selection = (IStructuredSelection) tv.getSelection();
			ITreeEntry entry = (ITreeEntry) (selection.getFirstElement());
			tv.setSubtreeChecked(entry, true); // false����ѡ
		}
	}

	// ɾ������Action��
	private class RemoveEntryAction extends Action {
		public RemoveEntryAction() {
			setText("ɾ��");
		}

		public void run() {
			Object[] checks = tv.getCheckedElements();// ȡ�ñ���ѡ�Ľ�㣨������ѡ��
			if (checks.length == 0) {
				MessageDialog.openInformation(null, "��ʾ", "���ȹ�ѡ��¼");
				return;
			}
			List<ITreeEntry> inputList = (List<ITreeEntry>) tv.getInput();
			for (Object object : checks) {
				if (tv.getGrayed(object))
					continue;// ��ѡ��㲻ɾ��
				ITreeEntry entry = (ITreeEntry) object;
				remove(inputList, entry);
				tv.remove(entry);
			}
		}

		private void remove(List<ITreeEntry> list, ITreeEntry entry) {
			if (list == null)
				return;
			for (Iterator it = list.iterator(); it.hasNext();) {
				ITreeEntry o = (ITreeEntry) it.next();
				if (o.getName().equals(entry.getName())) {
					it.remove();
					return;
				} else {
					remove(o.getChildren(), entry);
				}
			}
		}
	}
}
