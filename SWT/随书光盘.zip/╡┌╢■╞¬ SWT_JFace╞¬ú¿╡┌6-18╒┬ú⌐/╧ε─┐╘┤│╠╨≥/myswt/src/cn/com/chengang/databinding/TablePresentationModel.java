package cn.com.chengang.databinding;

import java.util.List;

import org.eclipse.jface.internal.databinding.provisional.observable.value.WritableValue;

public class TablePresentationModel {
	private List<City> input;
	private WritableValue selected;

	public TablePresentationModel(List<City> input) {
		this.input = input;
		this.selected = new WritableValue(City.class);
		this.selected.setValue(input.get(1));// Ĭ��ѡ��ڶ�����¼
	}

	public List<City> getInput() {
		return input;
	}

	public void setInput(List<City> input) {
		this.input = input;
	}

	public WritableValue getSelected() {
		return selected;
	}

	public void setSelected(WritableValue selected) {
		this.selected = selected;
	}
}
