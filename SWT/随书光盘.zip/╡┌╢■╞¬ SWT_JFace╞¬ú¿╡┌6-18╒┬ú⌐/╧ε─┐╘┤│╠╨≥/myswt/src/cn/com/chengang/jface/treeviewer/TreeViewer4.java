package cn.com.chengang.jface.treeviewer;

import java.util.List;

import org.eclipse.jface.action.MenuManager;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeColumn;
import org.eclipse.ui.dialogs.ContainerCheckedTreeViewer;

public class TreeViewer4 {
	public static void main(String[] args) {
		new TreeViewer4().open();
	}

	public void open() {
		final Display display = new Display();
		final Shell shell = new Shell();
		shell.setSize(300, 300);
		// -----------������Ĵ���-------------------
		shell.setLayout(new FillLayout());
		// ��ContainerCheckedTreeViewer��ȫ�滻TreeViewer
		ContainerCheckedTreeViewer tv = new ContainerCheckedTreeViewer(shell, SWT.BORDER);
		tv.setUseHashlookup(true); // �ӿ�����ٶ�

		Tree tree = tv.getTree();
		tree.setHeaderVisible(true);
		TreeColumn column = new TreeColumn(tree, SWT.LEFT);
		column.setText("����");
		column.setWidth(150);
		column = new TreeColumn(tree, SWT.LEFT);
		column.setText("�ӽ����");
		column.setWidth(80);
		column = new TreeColumn(tree, SWT.LEFT);
		column.setText("�Ա�");
		column.setWidth(40);

		tv.setContentProvider(new TreeViewerContentProvider());
		tv.setLabelProvider(new MyTableLableProvider());
		// ��TableViewerһ�������ݵ����Ҳ��setInput����
		List<CountryEntity> input = DataFactory.createTreeData();
		tv.setInput(input);
		MyActionGroup2 actionGroup = new MyActionGroup2(tv);// ������һ��ActionGroup
		actionGroup.fillContextMenu(new MenuManager());// ����ťע�뵽�˵�������
		// -----------END------------------
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
