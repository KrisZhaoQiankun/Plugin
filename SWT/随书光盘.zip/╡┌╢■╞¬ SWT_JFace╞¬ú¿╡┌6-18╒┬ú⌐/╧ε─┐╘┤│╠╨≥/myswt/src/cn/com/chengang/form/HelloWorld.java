package cn.com.chengang.form;

import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.forms.widgets.FormToolkit;

public class HelloWorld {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		shell.setLayout(new RowLayout());
		FormToolkit toolkit = new FormToolkit(display);// ����һ��Form������
		Composite comp = toolkit.createComposite(shell);// �ɹ����䴴��Composite���
		comp.setLayout(new GridLayout());
		Label link = toolkit.createLabel(comp, "HelloWorld");
		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
