package cn.com.chengang.jface.dialog;

public class Human {
	private String name; // ����
	private int old;// ����
	private boolean sex;// �Ա�

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getOld() {
		return old;
	}

	public void setOld(int old) {
		this.old = old;
	}

	public boolean isSex() {
		return sex;
	}

	public void setSex(boolean sex) {
		this.sex = sex;
	}

}
