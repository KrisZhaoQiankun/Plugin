package cn.com.chengang.form;

import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.forms.widgets.Form;
import org.eclipse.ui.forms.widgets.FormToolkit;

public class Form1 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(200, 253);
		// ---------���������е������������-------------
		shell.setLayout(new FillLayout());
		FormToolkit toolkit = new FormToolkit(display);
		Form form = toolkit.createForm(shell);
		form.setText("���ڴ���Ի");
		form.setImage(new Image(display, "icons/project.gif"));
		Composite comp = form.getBody();
		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
