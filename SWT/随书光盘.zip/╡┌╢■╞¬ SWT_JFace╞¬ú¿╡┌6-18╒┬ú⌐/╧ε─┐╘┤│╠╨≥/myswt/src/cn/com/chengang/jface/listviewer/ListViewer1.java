package cn.com.chengang.jface.listviewer;

import org.eclipse.jface.viewers.ListViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import cn.com.chengang.jface.tableviewer.TableViewerContentProvider;
import cn.com.chengang.jface.treeviewer.CountryEntity;
import cn.com.chengang.jface.treeviewer.DataFactory;
import cn.com.chengang.jface.treeviewer.TreeViewerLableProvider;

public class ListViewer1 {
	public static void main(String[] args) {
		new ListViewer1().open();
	}

	public void open() {
		final Display display = new Display();
		final Shell shell = new Shell();
		shell.setSize(200, 300);
		// -----------������Ĵ���-------------------
		shell.setLayout(new FillLayout());
		ListViewer lv = new ListViewer(shell, SWT.BORDER);
		lv.setContentProvider(new TableViewerContentProvider());
		lv.setLabelProvider(new TreeViewerLableProvider());
		java.util.List input = DataFactory.createTreeData();
		lv.setInput(input);
		// ֱ�Ӽ�������
		lv.add(new CountryEntity("Ӣ��"));
		lv.add(new CountryEntity("����"));
		// -----------END------------------
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
