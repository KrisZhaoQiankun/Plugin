package cn.com.chengang.swt;

import org.eclipse.swt.SWT;
import org.eclipse.swt.awt.SWT_AWT;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class AwtInSwt {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ------------------�²���Ľ�����Ĵ���----------
		shell.setLayout(new RowLayout());
		Composite comp = new Composite(shell, SWT.EMBEDDED);// ������SWT.EMBEDDEDʽ��
		java.awt.Frame frame = SWT_AWT.new_Frame(comp);
		java.awt.Button button = new java.awt.Button();
		button.setLabel("AWT��ť");
		frame.add(button);
		// ------------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
