package cn.com.chengang.form;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.forms.widgets.FormToolkit;

public class CompositeSeparator1 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(200, 150);
		// ---------���������е������������-------------
		shell.setLayout(new RowLayout(SWT.VERTICAL));
		FormToolkit toolkit = new FormToolkit(display);
		toolkit.createLabel(shell, "Eclipse�����ŵ���ͨ");
		Composite form = toolkit.createCompositeSeparator(shell);
		form.setLayoutData(new RowData(150, 2));
		toolkit.createLabel(shell, "���ߣ��¸�");
		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
