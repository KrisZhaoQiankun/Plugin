package cn.com.chengang.form;

import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.forms.FormColors;
import org.eclipse.ui.forms.widgets.FormText;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.TableWrapLayout;

public class FormText1 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(200, 253);
		// ---------���������е������������-------------
		shell.setLayout(new FillLayout());
		FormToolkit toolkit = new FormToolkit(display);
		Composite comp = toolkit.createComposite(shell);
		comp.setLayout(new TableWrapLayout());

		FormText text = toolkit.createFormText(comp, true);
		text.setImage("gif1", new Image(display, "icons/moon.jpg"));
		text.setImage("gif2", new Image(display, "icons/selectall.gif"));
		text.setColor("header", toolkit.getColors().getColor(FormColors.TITLE));
		text.setFont("header", JFaceResources.getHeaderFont());

		StringBuilder sb = new StringBuilder();
		sb.append("<root>");
		sb.append("<p><span color=\"header\" font=\"header\">Eclipse�����ŵ���ͨ</span></p>");
		sb.append("<p>http://www.chengang.com.cn ����һ������Eclipse<img href=\"gif1\"/>����</p>");
		sb.append("<li style='image' value='gif2'>����SWT/JFace����</li>");
		sb.append("<li style=\"image\" value=\"gif2\">����Eclipse���</li>");
		sb.append("<li style=\"image\" value=\"gif2\">��ʾ<b>RCPƽ̨</b>�Ŀ���</li>");
		sb.append("<li style=\"image\" value=\"gif2\">���ý�����</li>");
		sb.append("</root>");
		text.setText(sb.toString(), true, true);
		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
