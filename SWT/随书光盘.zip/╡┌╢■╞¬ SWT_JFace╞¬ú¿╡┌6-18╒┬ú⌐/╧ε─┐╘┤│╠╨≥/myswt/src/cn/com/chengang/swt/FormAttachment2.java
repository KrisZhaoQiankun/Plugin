package cn.com.chengang.swt;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class FormAttachment2 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		shell.setLayout(new FormLayout());
		Text text1 = new Text(shell, SWT.BORDER);
		text1.setLayoutData(new FormData(100, 50));
		// ���岢����FormData
		FormData formData = new FormData();
		// ��text1Ϊ��׼ƫ��50����
		FormAttachment formAttachment = new FormAttachment(text1, 50);
		// FormAttachment formAttachment = new FormAttachment(text1, 50,
		// SWT.LEFT);����3�Ŀ�ѡֵ����SWT.DEFAULT��SWT.LEFT��SWT.CENTER��SWT.RIGHT��SWT.TOP��SWT.BOTTOM
		formData.top = formAttachment;
		formData.left = formAttachment;
		// ��button1Ӧ��FormData
		Button button1 = new Button(shell, SWT.NONE);
		button1.setText("button1");
		button1.setLayoutData(formData);
		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
