package cn.com.chengang.swt;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class GridData2 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		shell.setLayout(new GridLayout());
		Button b1 = new Button(shell, SWT.NONE);
		GridData gridData = new GridData();
		gridData.horizontalAlignment = GridData.BEGINNING;
		b1.setLayoutData(gridData);
		b1.setText("b1");
		new Button(shell, SWT.NONE).setText("button2");
		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
