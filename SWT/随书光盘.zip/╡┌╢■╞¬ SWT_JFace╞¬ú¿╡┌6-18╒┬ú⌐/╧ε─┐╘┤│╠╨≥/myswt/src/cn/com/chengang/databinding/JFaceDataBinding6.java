package cn.com.chengang.databinding;

import java.util.ArrayList;
import java.util.Arrays;

import org.eclipse.jface.internal.databinding.provisional.DataBindingContext;
import org.eclipse.jface.internal.databinding.provisional.description.Property;
import org.eclipse.jface.internal.databinding.provisional.observable.value.WritableValue;
import org.eclipse.jface.internal.databinding.provisional.swt.SWTProperties;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

public class JFaceDataBinding6 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		shell.setLayout(new RowLayout());
		final People bean = new People();// ����
		ArrayList<String> interests = new ArrayList<String>(3);
		interests.add("�Ķ�");
		interests.add("����");
		interests.add("�˶�");
		bean.setInterests(interests);

		Button button = new Button(shell, SWT.NONE);
		button.setText("��ӡ����");
		button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				System.out.println("---------------------------------");
				System.out.println("name=" + bean.getName());
				System.out.println("age=" + bean.getAge());
				System.out.println("sex=" + bean.isSex());
				System.out.println("interests=" + Arrays.toString(bean.getInterests().toArray()));
			}
		});

		// �������
		Combo combo = new Combo(shell, SWT.BORDER);
		Label label = new Label(shell, SWT.BORDER);
		label.setLayoutData(new RowData(100, -1));

		// ���ݰ�
		DataBindingContext ctx = DataBindingContextFactory.createContext(shell);
		ctx.bind(new Property(combo, SWTProperties.ITEMS), new Property(bean, "interests", String.class, true), null);
		WritableValue selectedItem = new WritableValue(String.class);
		selectedItem.setValue("����");// ���ó�ѡֵ
		ctx.bind(new Property(combo, SWTProperties.SELECTION), selectedItem, null);
		ctx.bind(label, selectedItem, null);
		// ctx.bind(label, new Property(combo, SWTProperties.SELECTION), null);
		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

}
