package cn.com.chengang.databinding;

import java.util.Arrays;

import org.apache.commons.lang.math.NumberUtils;
import org.eclipse.jface.internal.databinding.provisional.BindSpec;
import org.eclipse.jface.internal.databinding.provisional.DataBindingContext;
import org.eclipse.jface.internal.databinding.provisional.description.Property;
import org.eclipse.jface.internal.databinding.provisional.validation.IValidator;
import org.eclipse.jface.internal.databinding.provisional.validation.ValidationError;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class JFaceDataBinding2 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		shell.setLayout(new RowLayout());
		final People bean = new People();// ����
		Button button = new Button(shell, SWT.NONE);
		button.setText("��ӡ����");
		button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				System.out.println("---------------------------------");
				System.out.println("name=" + bean.getName());
				System.out.println("age=" + bean.getAge());
				System.out.println("sex=" + bean.isSex());
				System.out.println("interests=" + Arrays.toString(bean.getInterests().toArray()));
				System.out.println("cities=" + Arrays.toString(bean.getCities().toArray()));
			}
		});

		// �������
		Text ageText = new Text(shell, SWT.BORDER);
		ageText.setLayoutData(new RowData(50, -1));
		// ���ݰ�
		DataBindingContext ctx = DataBindingContextFactory.createContext(shell);
		BindSpec spec = new BindSpec(null, null, new MyValidator(), null);
		ctx.bind(ageText, new Property(bean, "age"), spec);

		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	private static class MyValidator implements IValidator {
		// �ı���ÿ�������ַ�����ִ�д˷���
		public ValidationError isPartiallyValid(Object value) {
			System.out.println("isPartiallyValid=" + value);
			if (NumberUtils.isNumber((String) value))
				return null;
			else
				return new ValidationError(ValidationError.ERROR, "��Ч������");
		}

		// �ı����һ����ֵʱִ��һ�δ˷������������ʧȥ����ʱ��ִ��һ��
		public ValidationError isValid(Object value) {
			if ("0".equals(value))
				return ValidationError.error("����������0");
			else
				return null;
		}
	}
}
