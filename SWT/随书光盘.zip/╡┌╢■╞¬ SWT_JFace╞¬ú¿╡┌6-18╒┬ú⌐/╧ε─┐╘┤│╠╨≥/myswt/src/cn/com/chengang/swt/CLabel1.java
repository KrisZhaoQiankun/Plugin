package cn.com.chengang.swt;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class CLabel1 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(200, 100);
		// ---------���������е������������-------------
		shell.setLayout(new FillLayout());
		CLabel clabel = new CLabel(shell, SWT.NONE);
		clabel.setText("Eclipse�����ŵ���ͨ");
		clabel.setImage(new Image(display, "icons/project.gif"));
		Color[] colors = { display.getSystemColor(SWT.COLOR_GREEN), //
				display.getSystemColor(SWT.COLOR_RED), //
				display.getSystemColor(SWT.COLOR_BLUE) };
		int[] percents = { 30, 100 };
		clabel.setBackground(colors, percents);
		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
