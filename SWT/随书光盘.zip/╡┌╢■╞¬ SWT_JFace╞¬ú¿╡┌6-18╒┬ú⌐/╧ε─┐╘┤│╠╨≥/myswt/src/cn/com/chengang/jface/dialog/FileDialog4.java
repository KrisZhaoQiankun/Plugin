package cn.com.chengang.jface.dialog;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;

public class FileDialog4 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		FileDialog dlg = new FileDialog(shell, SWT.SAVE);
		String fileName = dlg.open();
		if (fileName != null)
			System.out.println(fileName);
		// -----------------END------------------------
		// shell.layout();
		// shell.open();
		shell.dispose();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
