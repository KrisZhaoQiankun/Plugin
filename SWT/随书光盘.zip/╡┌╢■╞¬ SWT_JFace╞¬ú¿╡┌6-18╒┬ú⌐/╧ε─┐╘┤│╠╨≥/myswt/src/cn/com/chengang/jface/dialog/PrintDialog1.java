package cn.com.chengang.jface.dialog;

import org.eclipse.swt.printing.PrintDialog;
import org.eclipse.swt.printing.Printer;
import org.eclipse.swt.printing.PrinterData;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class PrintDialog1 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		PrintDialog dialog = new PrintDialog(shell);
		PrinterData printerData = dialog.open();
		if (printerData != null) {
			Printer printer = new Printer(printerData);
			// ʹ��printer���� �������ǵ�����󣬵���printer.dispose()��printer�ͷŵ�
		}
		// -----------------END------------------------
		// shell.layout();
		// shell.open();
		shell.dispose();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
