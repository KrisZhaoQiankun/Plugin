package cn.com.chengang.jface.dialog;

import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class InputDialog1 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
//		InputDialog dialog = new InputDialog(shell, "����", "������ֵ", "1", null);
		InputDialog dialog = new InputDialog(shell, "����", "������ֵ", "1", new MyValidator());
		if (dialog.open() == InputDialog.OK) {
			String vlaueStr = dialog.getValue();
			System.out.println("����ֵ��" + vlaueStr);
		}
		// -----------------END------------------------
//		shell.layout();
//		shell.open();
		shell.dispose();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
