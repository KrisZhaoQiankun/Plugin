package cn.com.chengang.databinding;

import java.util.Arrays;

import org.eclipse.jface.internal.databinding.provisional.BindSpec;
import org.eclipse.jface.internal.databinding.provisional.DataBindingContext;
import org.eclipse.jface.internal.databinding.provisional.conversion.IConverter;
import org.eclipse.jface.internal.databinding.provisional.description.Property;
import org.eclipse.jface.internal.databinding.provisional.swt.SWTProperties;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class JFaceDataBinding3 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		shell.setLayout(new RowLayout());
		final People bean = new People();// ����
		Button button = new Button(shell, SWT.NONE);
		button.setText("��ӡ����");
		button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				System.out.println("---------------------------------");
				System.out.println("name=" + bean.getName());
				System.out.println("age=" + bean.getAge());
				System.out.println("sex=" + bean.isSex());
				System.out.println("interests=" + Arrays.toString(bean.getInterests().toArray()));
				System.out.println("cities=" + Arrays.toString(bean.getCities().toArray()));
			}
		});

		// �������
		Combo combo = new Combo(shell, SWT.READ_ONLY);
		combo.setItems(new String[] { "��", "Ů" });
		// ���ݰ�
		DataBindingContext ctx = DataBindingContextFactory.createContext(shell);
		BindSpec spec = new BindSpec(new BooleanToStringConverter(), new StringToBooleanConverter(), null, null);
		ctx.bind(new Property(combo, SWTProperties.SELECTION), new Property(bean, "sex"), spec);

		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

	private static class BooleanToStringConverter implements IConverter {
		public Object convert(Object fromObject) {
			if ((Boolean) fromObject)
				return "��";
			else
				return "Ů";
		}

		public Object getFromType() {
			return Boolean.TYPE;
		} // ����ֵ������

		public Object getToType() {
			return String.class;
		} // ת����ֵ������
	}

	private static class StringToBooleanConverter implements IConverter {
		public Object convert(Object fromObject) {
			return "��".equals(fromObject);
		}

		public Object getFromType() {
			return String.class;
		}

		public Object getToType() {
			return Boolean.TYPE;
		}
	}

}
