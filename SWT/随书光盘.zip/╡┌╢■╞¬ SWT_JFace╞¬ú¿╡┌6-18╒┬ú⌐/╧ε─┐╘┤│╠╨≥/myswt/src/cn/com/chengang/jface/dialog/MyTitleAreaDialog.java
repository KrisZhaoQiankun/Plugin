package cn.com.chengang.jface.dialog;

import org.eclipse.jface.dialogs.IMessageProvider;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class MyTitleAreaDialog extends TitleAreaDialog {

	public MyTitleAreaDialog(Shell parentShell) {
		super(parentShell);
	}

	protected Control createDialogArea(Composite parent) {
		setTitle("�Ի������");
		setMessage("�����ı�������������");
		 setMessage("�Ի����˵������", IMessageProvider.INFORMATION);
		// setErrorMessage("�������");
		Composite topComp = new Composite(parent, SWT.BORDER);
		topComp.setLayoutData(new GridData(GridData.FILL_BOTH));
		topComp.setLayout(new RowLayout());
		new Label(topComp, SWT.NONE).setText("�����룺");
		Text text = new Text(topComp, SWT.BORDER);
		text.setLayoutData(new RowData(100, -1));
		return topComp;
	}
}