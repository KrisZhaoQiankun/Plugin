package cn.com.chengang.databinding;

import org.eclipse.jface.internal.databinding.provisional.conversion.IConverter;
import org.eclipse.jface.internal.databinding.provisional.validation.ValidationError;

public class ValidationErrorToStringConverter implements IConverter {
	public Object convert(Object fromObject) {
		return fromObject == null ? null : fromObject.toString();
	}

	public Object getFromType() {
		return ValidationError.class;
	}

	public Object getToType() {
		return String.class;
	}
}
