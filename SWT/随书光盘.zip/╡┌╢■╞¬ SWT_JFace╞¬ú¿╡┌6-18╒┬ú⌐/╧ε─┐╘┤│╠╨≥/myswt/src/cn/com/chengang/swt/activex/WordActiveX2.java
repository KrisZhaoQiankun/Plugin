package cn.com.chengang.swt.activex;

import java.io.File;
import java.net.URISyntaxException;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.ole.win32.OLE;
import org.eclipse.swt.ole.win32.OleAutomation;
import org.eclipse.swt.ole.win32.OleClientSite;
import org.eclipse.swt.ole.win32.OleFrame;
import org.eclipse.swt.ole.win32.Variant;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;

public class WordActiveX2 {

	public static void main(String[] args) throws URISyntaxException {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(500, 450);
		// ---------���������е������������-------------
		shell.setLayout(new FillLayout());
		OleFrame oleFrame = new OleFrame(shell, SWT.NONE);

		// --------------------- �����˵�----------------------------------
		Menu bar = new Menu(shell, SWT.BAR);
		shell.setMenuBar(bar);
		// �����˵���
		MenuItem menu1 = new MenuItem(bar, SWT.CASCADE);
		menu1.setText("menu1");
		MenuItem menu2 = new MenuItem(bar, SWT.CASCADE);
		menu2.setText("menu2");
		MenuItem menu3 = new MenuItem(bar, SWT.CASCADE);
		menu3.setText("menu3");
		// ���˵���Ƕ��OLE����
		oleFrame.setFileMenus(new MenuItem[] { menu1 });
		oleFrame.setContainerMenus(new MenuItem[] { menu2 });
		oleFrame.setWindowMenus(new MenuItem[] { menu3 });
		// --------------------- �����˵�����----------------------------------

		File file = new File(WordActiveX1.class.getResource("a.doc").toURI());
		final OleClientSite clientSite = new OleClientSite(oleFrame, SWT.NONE, file);
		clientSite.doVerb(OLE.OLEIVERB_SHOW);
		System.out.println(clientSite.getProgramID());

		// ���򿪵��ļ�����Ϊ��һ���ļ�����Ϊ��Ҫ��clientSite�������԰���������ں���
		menu1.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				File file = new File("c:\\b.doc");
				boolean success = clientSite.save(file, true);
				System.out.println(success ? "�ɹ�" : "ʧ��");
			}
		});
		// ����Word�ؼ���ȫѡ����
		menu2.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				OleAutomation automation = new OleAutomation(clientSite);
				// ȡ��ȫѡ����Select��Ӧ��id
				int[] methodIDs = automation.getIDsOfNames(new String[] { "Select" });
				int methodID = methodIDs[0];
				System.out.println("methodID = " + methodID);
				Variant result = automation.invoke(methodID);
				System.out.println(result != null ? "���óɹ�" : "����ʧ��");
				System.out.println(result);
				automation.dispose();
			}
		});
		// -----------------END------------------------
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

}
