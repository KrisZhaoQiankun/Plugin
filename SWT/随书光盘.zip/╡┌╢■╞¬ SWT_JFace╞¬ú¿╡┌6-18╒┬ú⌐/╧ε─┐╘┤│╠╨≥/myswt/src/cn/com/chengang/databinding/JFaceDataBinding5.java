package cn.com.chengang.databinding;

import java.util.ArrayList;
import java.util.Arrays;

import org.eclipse.jface.internal.databinding.provisional.DataBindingContext;
import org.eclipse.jface.internal.databinding.provisional.description.Property;
import org.eclipse.jface.internal.databinding.provisional.description.TableModelDescription;
import org.eclipse.jface.internal.databinding.provisional.viewers.ViewersProperties;
import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

public class JFaceDataBinding5 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		shell.setLayout(new RowLayout());
		final People bean = new People();// ����
		ArrayList<City> cities = new ArrayList<City>(3);
		cities.add(new City("����", "ɽˮ������"));
		cities.add(new City("����", "�����Ŀ�������"));
		cities.add(new City("����", "������ʡ�����"));
		cities.add(new City("����", "�й��׶�"));
		bean.setCities(cities);
		TablePresentationModel tableModel = new TablePresentationModel(bean.getCities());

		Button button = new Button(shell, SWT.NONE);
		button.setText("��ӡ����");
		button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				System.out.println("---------------------------------");
				System.out.println("name=" + bean.getName());
				System.out.println("age=" + bean.getAge());
				System.out.println("sex=" + bean.isSex());
				System.out.println("interests=" + Arrays.toString(bean.getInterests().toArray()));
			}
		});

		// �������
		TableViewer tv = new TableViewer(shell, SWT.BORDER | SWT.FULL_SELECTION);
		Table table = tv.getTable();
		table.setLayoutData(new RowData(150, 70));
		table.setHeaderVisible(true); // ��ʾ��ͷ
		table.setLinesVisible(true); // ��ʾ������
		TableLayout layout = new TableLayout();
		table.setLayout(layout);
		layout.addColumnData(new ColumnWeightData(13));
		new TableColumn(table, SWT.NONE).setText("����");
		layout.addColumnData(new ColumnWeightData(40));
		new TableColumn(table, SWT.NONE).setText("ע��");

		Label label = new Label(shell, SWT.BORDER);

		// ���ݰ�
		DataBindingContext ctx = DataBindingContextFactory.createContext(shell);
		TableModelDescription dec = new TableModelDescription(new Property(tableModel, "input", City.class, true), new String[] { "name", "desc" });
		ctx.bind(new Property(tv, ViewersProperties.CONTENT), dec, null);
		ctx.bind(new Property(tv, ViewersProperties.SINGLE_SELECTION), tableModel.getSelected(), null);
		ctx.bind(label, new Property(tableModel.getSelected(), "name", String.class, false), null);
		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

}
