package cn.com.chengang.jface.dialog;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

public class MessageBox1 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		MessageBox messageBox = new MessageBox(shell);
		messageBox.setMessage("Hello World!");
		messageBox.open();
		// -----------------END------------------------
//		shell.layout();
//		shell.open();
		shell.dispose();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
