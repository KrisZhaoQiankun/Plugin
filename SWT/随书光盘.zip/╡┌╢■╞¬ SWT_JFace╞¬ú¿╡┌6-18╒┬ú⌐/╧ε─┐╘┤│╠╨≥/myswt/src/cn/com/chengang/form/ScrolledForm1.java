package cn.com.chengang.form;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;
import org.eclipse.ui.forms.widgets.TableWrapLayout;

public class ScrolledForm1 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(200, 150);
		// ---------���������е������������-------------
		shell.setLayout(new FillLayout());
		FormToolkit toolkit = new FormToolkit(display);
		ScrolledForm form = toolkit.createScrolledForm(shell);
		form.setText("���ڴ���Ի");
		form.setImage(new Image(display, "icons/project.gif"));
		Composite comp = form.getBody();
		TableWrapLayout layout = new TableWrapLayout();
		layout.numColumns = 4;
		comp.setLayout(layout);
		for (int i = 0; i < 40; i++)
			toolkit.createButton(comp, "button" + i, SWT.NONE);
		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
