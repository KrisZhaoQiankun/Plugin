package cn.com.chengang.databinding;

import java.util.Arrays;

import org.eclipse.jface.internal.databinding.provisional.DataBindingContext;
import org.eclipse.jface.internal.databinding.provisional.description.Property;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class JFaceDataBinding1 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		shell.setLayout(new RowLayout());
		final People bean = new People(); // ����
		Button button = new Button(shell, SWT.NONE);
		button.setText("��ӡ����");
		button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				System.out.println("---------------------------------");
				System.out.println("name=" + bean.getName());
				System.out.println("age=" + bean.getAge());
				System.out.println("sex=" + bean.isSex());
				System.out.println("interests=" + Arrays.toString(bean.getInterests().toArray()));
				System.out.println("cities=" + Arrays.toString(bean.getCities().toArray()));
			}
		});
		Text nameText = new Text(shell, SWT.BORDER);
		DataBindingContext ctx = DataBindingContextFactory.createContext(shell);
		ctx.bind(nameText, new Property(bean, "name"), null);
		// ctx.bind(new Property(nameText, "enabled"), new Property(bean, "sex"),null);
		// ctx.bind(new Property(nameText, "visible"), new Property(bean, "sex"),null);
		// -----------------END------------------------
		shell.layout();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

}
