package cn.com.chengang.jface.dialog;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;

public class FileDialog3 {
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(327, 253);
		// ---------���������е������������-------------
		FileDialog dialog = new FileDialog(shell, SWT.OPEN | SWT.MULTI);
		dialog.setFilterNames(new String[] { "��ִ���ļ� (*.exe)", "Microsoft Excel (*.xls)" });
		dialog.setFilterExtensions(new String[] { "*.exe", "*.xls", "*.jpg", "*.*" });
		String fileName = dialog.open();
		System.out.println(fileName);
		// -----------------END------------------------
		// shell.layout();
		// shell.open();
		shell.dispose();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
