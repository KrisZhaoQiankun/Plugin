package cn.com.chengang.jface.dialog;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class MyTitleAreaDialogClient {
	public static void main(String[] args) {
		Display display = Display.getDefault();
		Shell shell = new Shell(display);

		new MyTitleAreaDialog(shell).open();

		display.dispose();
	}
}
